<?php

defined('TEMPLAZA_FRAMEWORK') or exit();

use TemPlazaFramework\Functions;
use TemPlazaFramework\Templates;

?>

            </div><!-- Wrapper -->
        </div><!-- Layout -->
    </div><!-- Content -->
    <?php Templates::load_my_header('backtotop'); ?>

</div><!-- Container -->

<?php //Templates::load_my_layout('preloader'); ?>