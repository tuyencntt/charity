<?php

defined('TEMPLAZA_FRAMEWORK') or exit();

get_header();
do_action('templaza-framework_theme_body');
get_footer();