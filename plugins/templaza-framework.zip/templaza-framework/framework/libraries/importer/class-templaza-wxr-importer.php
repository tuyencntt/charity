<?php

defined( 'ABSPATH' ) || exit;

if( class_exists( 'WXR_Importer') ) {
class TemplazaFramework_WXR_Importer extends WXR_Importer {}
}
