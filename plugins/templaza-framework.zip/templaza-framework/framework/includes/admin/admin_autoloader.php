<?php

defined( 'TEMPLAZA_FRAMEWORK' ) || exit;

require_once TEMPLAZA_FRAMEWORK_CORE_INCLUDES_PATH.'/classes/class-templaza-basecontroller.php';
require_once TEMPLAZA_FRAMEWORK_LIBRARY_PATH.'/helper/http.php';
require_once TEMPLAZA_FRAMEWORK_LIBRARY_PATH.'/helper/files.php';
require_once TEMPLAZA_FRAMEWORK_LIBRARY_PATH.'/helper/info.php';
require_once TEMPLAZA_FRAMEWORK_LIBRARY_PATH.'/helper/helperlicense.php';
require_once 'admin_page_function.php';
require_once 'admin_page.php';
require_once 'application.php';


//require_once TEMPLAZA_FRAMEWORK_INSTALLATION_LIBRARY.'/files.php';
//require_once TEMPLAZA_FRAMEWORK_INSTALLATION_ADMIN_PATH.'/installation_adminfunctions.php';
//require_once TEMPLAZA_FRAMEWORK_INSTALLATION_LIBRARY.'/helperlicense.php';
//require_once TEMPLAZA_FRAMEWORK_INSTALLATION_LIBRARY.'/class-tgm-plugin-activation.php';
