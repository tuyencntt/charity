<?php

defined('TEMPLAZA_FRAMEWORK') or exit();

// Post type is templaza_style
require_once 'sections/general.php';
require_once 'sections/header.php';
require_once 'sections/menu.php';
require_once 'sections/typography.php';
require_once 'sections/color.php';
require_once 'sections/pages.php';
require_once 'sections/layout.php';
require_once 'sections/social.php';
require_once 'sections/miscellaneous.php';
require_once 'sections/custom.php';
