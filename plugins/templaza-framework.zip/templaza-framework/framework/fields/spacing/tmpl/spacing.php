<?php

/*
 * Acceptable values checks.  If the passed variable doesn't pass muster, we unset them
 * and reset them with default values to avoid errors.
 */

defined('TEMPLAZA_FRAMEWORK') or exit;

$unit_arr = Redux_Helpers::$array_units;

$unit_check     = $unit_arr;
$unit_check[]   = false;
$position       = array(
    'top'       => 'top',
    'left'      => 'left',
    'right'     => 'right',
    'bottom'    => 'bottom'
);
$hints          = isset($this -> field['hint'])?$this -> field['hint']:array(
    'top'    => esc_html__('Top', $this -> text_domain),
    'right'  => esc_html__('Right', $this -> text_domain),
    'bottom' => esc_html__('Bottom', $this -> text_domain),
    'left'   => esc_html__('Left', $this -> text_domain),
);

// If units field has a value but is not an acceptable value, unset the variable.
if ( ! Redux_Helpers::array_in_array( $this->field['units'], $unit_check ) ) {
    $this->field['units'] = 'px';
}

// If there is a default unit value  but is not an accepted value, unset the variable.
if ( ! Redux_Helpers::array_in_array( $this->value['units'], $unit_check ) ) {
    $this->value['units'] = 'px';
}

if ( false === $this->field['units'] ) {
    '' === $this->value['units'];
}

//if ( ! in_array( $this->field['mode'], array( 'margin', 'padding' ), true ) ) {
    if ( 'absolute' === $this->field['mode'] ) {
        $this->field['mode'] = '';
    } elseif(!$this -> field['mode']) {
        $this->field['mode'] = 'padding';
    }
//}

if($this -> field['mode'] == 'border-radius'){
    $position['top']        = 'top-left';
    $position['right']      = 'top-right';
    $position['bottom']     = 'bottom-right';
    $position['left']       = 'bottom-left';

    if(isset($this -> field['custom-position']) && count($this -> field['custom-position'])){
        $position   = array_merge($position, $this -> field['custom-position']);
    }

    $hints['top']       = esc_html__('Top Left', $this -> text_domain);
    $hints['right']     = esc_html__('Top Right', $this -> text_domain);
    $hints['bottom']    = esc_html__('Bottom Right', $this -> text_domain);
    $hints['left']      = esc_html__('Bottom Left', $this -> text_domain);

}

$value = array(
    'top'    => isset( $this->value[ $this->field['mode'] . '-'.$position['top'] ] ) ? filter_var( $this->value[ $this->field['mode'] . '-'.$position['top'] ], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['top'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
    'right'  => isset( $this->value[ $this->field['mode'] . '-'.$position['right'] ] ) ? filter_var( $this->value[ $this->field['mode'] . '-'.$position['right'] ], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['right'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
    'bottom' => isset( $this->value[ $this->field['mode'] . '-'.$position['bottom'] ] ) ? filter_var( $this->value[ $this->field['mode'] . '-'.$position['bottom']  ], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['bottom'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
    'left'   => isset( $this->value[ $this->field['mode'] . '-'.$position['left'] ] ) ? filter_var( $this->value[ $this->field['mode'] .'-'.$position['left'] ], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['left'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
);

// if field units has a value and is NOT an array, then evaluate as needed.
if ( ! is_array( $this->field['units'] ) ) {

    // If units fields has a value and is not empty but units value does not then make units value the field value.
    if ( '' === $this->value['units'] && ( '' !== $this->field['units'] || false === $this->field['units'] ) ) {
        $this->value['units'] = $this->field['units'];

        // If units field does NOT have a value and units value does NOT have a value, set both to blank (default?).
    } elseif ( '' === $this->field['units'] && '' === $this->value['units'] ) {
        $this->field['units'] = 'px';
        $this->value['units'] = 'px';

        // If units field has NO value but units value does, then set unit field to value field.
    } elseif ( '' === $this->field['units'] && '' !== $this->value['units'] ) {
        $this->field['units'] = $this->value['units'];

        // if unit value is set and unit value doesn't equal unit field (coz who knows why)
        // then set unit value to unit field.
    } elseif ( '' !== $this->value['units'] && $this->field['units'] !== $this->value['units'] ) {
        $this->value['units'] = $this->field['units'];
    }

    // do stuff based on unit field NOT set as an array.
    // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
} elseif ( ! empty( $this->field['units'] ) && is_array( $this->field['units'] ) ) {
    // nothing to do here, but I'm leaving the construct just in case I have to debug this again.
}

if ( '' !== $this->field['units'] ) {
    $value['units'] = $this->value['units'];
}

$this->value = $value;

if ( '' !== $this->field['mode'] ) {
    $this->field['mode'] = $this->field['mode'] . '-';
}

if ( isset( $this->field['select2'] ) ) {
    $this->field['select2'] = wp_parse_args( $this->field['select2'], $this->select2_config );
} else {
    $this->field['select2'] = $this->select2_config;
}

$this->field['select2'] = Redux_Functions::sanitize_camel_case_array_keys( $this->field['select2'] );

$select2_data = Redux_Functions::create_data_string( $this->field['select2'] );

echo '<input 
					type="hidden" 
					name="' . esc_attr( $this->field['name'] . $this->field['name_suffix'] ) . '[units]" 
					class="field-units" value="' . esc_attr( $this->value['units'] ) . '">';

if ( true === $this->field['all'] ) {
    $this->field['top']    = true;
    $this->field['right']  = true;
    $this->field['bottom'] = true;
    $this->field['left']   = true;

    $this->value['bottom'] = $this->value['top'];
    $this->value['left']   = $this->value['top'];
    $this->value['right']  = $this->value['top'];

    echo '<div class="field-spacing-input input-prepend">
                        <span class="add-on">
                            <i class="el el-fullscreen icon-large"></i>
                        </span>
                        <input 
                            type="text" 
                            class="redux-spacing-all redux-spacing-input mini ' . esc_attr( $this->field['class'] ) . '" 
                            placeholder="' . $hints['all'] . '" 
                            rel="' . esc_attr( $this->field['id'] ) . '-all" 
                            value="' . esc_attr( $this->value['top'] ) . '"
                        >
                      </div>';
}

//if($this -> field['mode'] == 'border-radius'){
//    $position['top']        = 'top-right';
//    $position['right']      = 'bottom-right';
//    $position['left']       = 'top-left';
//    $position['bottom']     = 'bottom-left';
//    foreach ($this -> field['custom_position'] as $position => $enable){
//        if ( true === $enable ) {
//        ?>
<!--        <input-->
<!--            type="hidden"-->
<!--            class="redux-spacing-value"-->
<!--            id="--><?php //echo esc_attr( $this->field['id'] ); ?><!---top"-->
<!--            name="--><?php //echo esc_attr( $this->field['name'] . $this->field['name_suffix'] . '[' . $this->field['mode'] ).$position. ']';?><!--"-->
<!--            value="--><?php //echo esc_attr( $this->value['top'] ) . ( ! empty( $this->value['top'] ) ? esc_attr( $this->value['units'] ) : '' );?><!--"-->
<!--        >-->
<!--        --><?php //}
//        if ( false === $this->field['all'] ) {
//            if ( true === $enable ) {
//            ?>
<!--                <div class="field-spacing-input input-prepend">-->
<!--                    <span class="add-on">-->
<!--                        <i class="el el-arrow-up icon-large"></i>-->
<!--                    </span>-->
<!--                    <input type="text"-->
<!--                           class="redux-spacing-top redux-spacing-input mini --><?php //echo esc_attr( $this->field['class'] ); ?><!--"-->
<!--                           placeholder="--><?php //echo $hints[$position];?><!--"-->
<!--                           rel="--><?php //echo esc_attr( $this->field['id'] ) .'-'. $position;?><!--"-->
<!--                           value="--><?php //echo esc_attr( $this->value[$position] ); ?><!--"/>-->
<!--                </div>-->
<!--        --><?php //}
//        } ?>
<?php
//    }
//}else{

    if ( true === $this->field['top'] ) {
        echo '<input 
                            type="hidden" 
                            class="redux-spacing-value" 
                            id="' . esc_attr( $this->field['id'] ).'-'.$position['top'] . '" 
                            name="' . esc_attr( $this->field['name'] . $this->field['name_suffix'] . '[' . $this->field['mode'] ) .$position['top']. ']" 
                            value="' . esc_attr( $this->value['top'] ) . ( ! empty( $this->value['top'] ) ? esc_attr( $this->value['units'] ) : '' ) . '"
                          >';
    }

    if ( true === $this->field['right'] ) {
        echo '<input 
                            type="hidden" 
                            class="redux-spacing-value" 
                            id="' . esc_attr( $this->field['id'] ).'-'.$position['right'] . '" 
                            name="' . esc_attr( $this->field['name'] . $this->field['name_suffix'] . '[' . $this->field['mode'] ) .$position['right']. ']" 
                            value="' . esc_attr( $this->value['right'] ) . ( ! empty( $this->value['right'] ) ? esc_attr( $this->value['units'] ) : '' ) . '"
                          >';
    }

    if ( true === $this->field['bottom'] ) {
        echo '<input 
                            type="hidden" 
                            class="redux-spacing-value" 
                            id="' . esc_attr( $this->field['id'] ) .'-'.$position['bottom'] . '" 
                            name="' . esc_attr( $this->field['name'] . $this->field['name_suffix'] . '[' . $this->field['mode'] ) .$position['bottom']. ']" 
                            value="' . esc_attr( $this->value['bottom'] ) . ( ! empty( $this->value['bottom'] ) ? esc_attr( $this->value['units'] ) : '' ) . '"
                          >';
    }

    if ( true === $this->field['left'] ) {
        echo '<input 
                            type="hidden" 
                            class="redux-spacing-value" 
                            id="' . esc_attr( $this->field['id'] ) .'-'.$position['left'] . '" 
                            name="' . esc_attr( $this->field['name'] . $this->field['name_suffix'] . '[' . $this->field['mode'] ) .$position['left']. ']" 
                            value="' . esc_attr( $this->value['left'] ) . ( ! empty( $this->value['left'] ) ? esc_attr( $this->value['units'] ) : '' ) . '"
                          >';
    }

    if ( false === $this->field['all'] ) {
        /**
         * Top
         * */
        if ( true === $this->field['top'] ) {
            echo '<div class="field-spacing-input input-prepend">
                                <span class="add-on">
                                    <i class="el el-arrow-up icon-large"></i>
                                </span>
                                <input type="text" 
                                       class="redux-spacing-top redux-spacing-input mini ' . esc_attr( $this->field['class'] ) . '"
                                       placeholder="' . $hints['top'] . '"
                                       rel="' . esc_attr( $this->field['id'] ) .'-'.$position['top']. '"
                                       value="' . esc_attr( $this->value['top'] ) . '"/>
                            </div>';
        }

        /**
         * Right
         * */
        if ( true === $this->field['right'] ) {
            echo '<div class="field-spacing-input input-prepend">
                                <span class="add-on">
                                    <i class="el el-arrow-right icon-large"></i>
                                </span>
                                <input type="text" 
                                       class="redux-spacing-right redux-spacing-input mini ' . esc_attr( $this->field['class'] ) . '"
                                       placeholder="' .$hints['right'] . '"
                                       rel="' . esc_attr( $this->field['id'] ).'-'.$position['right'] . '"
                                       value="' . esc_attr( $this->value['right'] ) . '"/>
                            </div>';
        }

        /**
         * Bottom
         * */
        if ( true === $this->field['bottom'] ) {
            echo '<div class="field-spacing-input input-prepend">
                                <span class="add-on">
                                    <i class="el el-arrow-down icon-large"></i>
                                </span>
                                <input type="text" 
                                       class="redux-spacing-bottom redux-spacing-input mini ' . esc_attr( $this->field['class'] ) . '"
                                       placeholder="' . $hints['bottom'] . '"
                                       rel="' . esc_attr( $this->field['id'] ) .'-'.$position['bottom']. '"
                                       value="' . esc_attr( $this->value['bottom'] ) . '">
                            </div>';
        }

        /**
         * Left
         * */
        if ( true === $this->field['left'] ) {
            echo '<div class="field-spacing-input input-prepend">
                                <span class="add-on">
                                    <i class="el el-arrow-left icon-large"></i>
                                </span>
                                <input type="text" 
                                       class="redux-spacing-left redux-spacing-input mini ' . esc_attr( $this->field['class'] ) . '"
                                       placeholder="' . $hints['left'] . '"
                                       rel="' . esc_attr( $this->field['id'] ) .'-'.$position['left'] . '"
                                       value="' . esc_attr( $this->value['left'] ) . '"/>
                            </div>';
        }
    }
//}

/**
 * Units
 * */
if ( false !== $this->field['units'] && true === $this->field['display_units'] ) {
    echo '<div class="select_wrapper spacing-units" original-title="' . esc_html__( 'Units', 'redux-framework' ) . '">';
    echo '<select data-placeholder="' . esc_html__( 'Units', 'redux-framework' ) . '" class="redux-spacing redux-spacing-units select ' . esc_attr( $this->field['class'] ) . '" original-title="' . esc_html__( 'Units', 'redux-framework' ) . '" id="' . esc_attr( $this->field['id'] ) . '_units"' . esc_attr( $select2_data ) . '>';

    if ( $this->field['units_extended'] ) {
        $test_units = $unit_arr;
    } else {
        $test_units = array( 'px', 'em', 'pt', 'rem', '%' );
    }

    if ( '' !== $this->field['units'] || is_array( $this->field['units'] ) ) {
        $test_units = $this->field['units'];
    }

    echo '<option></option>';

    if ( ! is_array( $this->field['units'] ) ) {
        echo '<option value="' . esc_attr( $this->field['units'] ) . '" selected="selected">' . esc_attr( $this->field['units'] ) . '</option>';
    } else {
        foreach ( $test_units as $a_unit ) {
            echo '<option value="' . esc_attr( $a_unit ) . '" ' . selected( $this->value['units'], $a_unit, false ) . '>' . esc_html( $a_unit ) . '</option>';
        }
    }

    echo '</select></div>';
}
?>

