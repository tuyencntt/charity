<?php

defined('ABSPATH') or exit();

require_once __DIR__.'/defines.php';
require_once __DIR__.'/helper.php';
require_once TEMPLAZA_ELEMENTS_BUILDERS_PATH.'/includes/helper.php';