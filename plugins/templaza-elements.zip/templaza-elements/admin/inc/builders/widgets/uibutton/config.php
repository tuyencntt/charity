<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIButton' ) ) {
	/**
	 * Class Templaza_Elements_Config_UI_Button
	 */
	class Templaza_Elements_Config_UIButton extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uibutton';
			self::$name = esc_html__( 'TemPlaza: UI Button', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Button.', 'templaza-elements' );
			self::$icon = 'eicon-button';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'text', [
					'label' => __( 'Text', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'templaza-elements' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);
			$repeater->add_control(
				'link_title', [
					'label' => __( 'Link Title', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'icon_type',
				[
					'label' => __( 'Icon Type', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						''  => __( 'FontAwesome', 'templaza-elements' ),
						'uikit' => __( 'UIKit', 'templaza-elements' ),
					],
				]
			);
			$repeater->add_control(
				'icon',
				[
					'label' => __( 'Select Icon:', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'conditions' => [
						'terms' => [
							['name' => 'icon_type', 'operator' => '===', 'value' => ''],
						],
					],
				]
			);
			$repeater->add_control(
				'uikit_icon',
				[
					'label' => __( 'Select Icon:', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT2,
					'default' => '',
					'conditions' => [
						'terms' => [
							['name' => 'icon_type', 'operator' => '===', 'value' => 'uikit'],
						],
					],
					'options' => $this->get_font_uikit(),
				]
			);
			$repeater->add_control(
				'icon_position',
				[
					'label' => __( 'Icon Position', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						''  => __( 'Left', 'templaza-elements' ),
						'right' => __( 'Right', 'templaza-elements' ),
					],
				]
			);
			$repeater->add_control(
				'button_style',
				[
					'label' => __( 'Button Style', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements' ),
						'primary' => __('Primary', 'templaza-elements') ,
						'secondary' => __('Secondary', 'templaza-elements' ),
						'danger' => __('Danger', 'templaza-elements' ),
						'text' => __('Text', 'templaza-elements' ),
						'link' => __('Link', 'templaza-elements' ),
						'link-muted' => __('Link Muted', 'templaza-elements' ),
						'link-text' => __('Link Text', 'templaza-elements' ),
						'custom' => __('Custom', 'templaza-elements' ),
					],
				]
			);
			$repeater->add_control(
				'button_shape',
				[
					'label' => __( 'Button Shape', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'rounded',
					'options' => [
						'rounded' => __('Rounded', 'templaza-elements' ),
						'square' => __('Square', 'templaza-elements' ),
						'circle' => __('Circle', 'templaza-elements' ),
						'pill' => __('Pill', 'templaza-elements' ),
					],
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-muted'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-text'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'text'],
						],
					],
				]
			);
			$repeater->add_control(
				'background_color',
				[
					'label' => __( 'Background Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_control(
				'color',
				[
					'label' => __( 'Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'border',
					'label' => __( 'Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a',
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_control(
				'hover_background_color',
				[
					'label' => __( 'Hover Background Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a:hover' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_control(
				'hover_color',
				[
					'label' => __( 'Hover Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a:hover' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'hover_border',
					'label' => __( 'Hover Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a:hover',
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			// options
			$options = array(
				array(
					'type'      => Controls_Manager::REPEATER,
					'name'      => 'templaza-uibuttons',
					'label'     => esc_html__( 'Buttons', 'templaza-elements' ),
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'text' => 'Button Item',
						],
					],
					'title_field' => __( 'Button Item', 'templaza-elements' ),
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'font_weight',
					'label'         => esc_html__('Font Weight', 'templaza-elements'),
					'description'   => esc_html__('Add one of the following classes to modify the font weight of your button.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'light' => __('Light', 'templaza-elements'),
						'normal' => __('Normal', 'templaza-elements'),
						'bold' => __('Bold', 'templaza-elements'),
						'lighter' => __('Lighter', 'templaza-elements'),
						'bolder' => __('Bolder', 'templaza-elements'),
					),
					'default'           => '',
					'start_section' => 'misc',
					'section_name'      => esc_html__('Misc Settings', 'templaza-elements')
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'button_size',
					'label'         => esc_html__('Button Size', 'templaza-elements'),
					'description'   => esc_html__('Set the size for multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'default'           => '',
					'start_section' => 'misc',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'name'          => 'grid_width',
					'label'         => esc_html__('Full width button', 'templaza-elements'),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => 'yes',
					'default' => 'no',
					'start_section' => 'misc',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'grid_column_gap',
					'label'         => esc_html__('Column Gap', 'templaza-elements'),
					'description'   => esc_html__('Set the size of the column gap between multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'default'           => 'small',
					'start_section' => 'misc',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'grid_row_gap',
					'label'         => esc_html__('Row Gap', 'templaza-elements'),
					'description'   => esc_html__('Set the size of the row gap between multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'default'           => 'small',
					'start_section' => 'misc',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}