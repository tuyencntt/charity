<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIText' ) ) {
	/**
	 * Class Templaza_Elements_Config_UIText
	 */
	class Templaza_Elements_Config_UIText extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uitext';
			self::$name = esc_html__( 'TemPlaza: UI Text', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Text Box.', 'templaza-elements' );
			self::$icon = 'eicon-t-letter-bold';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			// options
			$options = array(
				array(
					'type'          => Controls_Manager::TEXTAREA,
					'name'          => 'title',
					'label'         => esc_html__( 'Title', 'templaza-elements' ),
					'default'       => __('Your Heading Text Here', 'templaza-elements'),
					'description'   => esc_html__( 'Write the title for the heading.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_tag',
					'label'         => esc_html__( 'Title tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
					),
					'default'       => 'h3',
					'description'   => esc_html__( 'Choose heading element.', 'templaza-elements' ),
					'condition'     => array(
						'title!'    => ''
					),
					/* vc */
					'admin_label' => false,
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'title_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon title.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-text .ui-text-title',
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'title_color',
					'label'         => esc_html__('Title Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of title.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-title' => 'color: {{VALUE}}',
					],
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_heading_style',
					'default'       => '',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Heading styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
					),
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_heading_extra_style',
					'default'       => '',
					'label'         => esc_html__('Extra Style', 'templaza-elements'),
					'description'   => esc_html__('Heading extra styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('None', 'templaza-elements'),
						'divider'   => esc_html__('Divider', 'templaza-elements'),
						'bullet'    => esc_html__('Bullet', 'templaza-elements'),
						'line'      => esc_html__('Line', 'templaza-elements'),
					),
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'title_heading_margin',
					'label'         => esc_html__('Title Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for title.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
					'condition'     => array(
						'title!'    => ''
					),
				),
				//Sub Title Settings
				array(
					'type'          => Controls_Manager::TEXTAREA,
					'name'          => 'sub_title',
					'label'         => esc_html__( 'Sub Title', 'templaza-elements' ),
					'placeholder'       => __('Your Sub Heading Text Here', 'templaza-elements'),
					'description'   => esc_html__( 'Write the title for the sub heading.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					'separator'     => 'before',
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'sub_title_tag',
					'label'         => esc_html__( 'Title tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
						'lead'      => 'lead',
						'meta'      => 'meta'
					),
					'default'       => 'lead',
					'description'   => esc_html__( 'Choose sub heading element.', 'templaza-elements' ),
					'condition'     => array(
						'sub_title!'    => ''
					),
					/* vc */
					'admin_label' => false,
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'sub_title_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Sub Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-text .ui-text-subtitle',
					'condition'     => array(
						'sub_title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'sub_title_color',
					'label'         => esc_html__('Sub Title Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of sub title.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'color: {{VALUE}}',
					],
					'condition'     => array(
						'sub_title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'sub_title_margin',
					'label'         => esc_html__('Sub Title Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for sub title.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
					'condition'     => array(
						'sub_title!'    => ''
					),
				),
				//Content Settings
				array(
					'name'          => 'text',
					'label'         => esc_html__('Content', 'templaza-elements'),
					'type' => Controls_Manager::WYSIWYG,
					'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras in semper sem. Praesent elit erat, suscipit sed varius ut, porta sit amet lorem. Duis eget vulputate turpis. Vivamus maximus ac nisl vel suscipit. Donec felis lacus, tristique in ante nec, varius ultrices felis. Quisque eget tellus magna. Sed hendrerit odio sit amet risus lobortis lobortis.', 'templaza-elements' ),
					'placeholder' => __( 'Type your description here', 'templaza-elements' ),
					'separator'     => 'before',
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'text_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-text .ui-text-desc',
					'condition'     => array(
						'text!'    => ''
					),
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}