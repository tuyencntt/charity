<?php
/**
 * Templaza_Elements Image config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_Templaza_Image' ) ) {
	/**
	 * Class Templaza_Elements_Config_Templaza_Image
	 */
	class Templaza_Elements_Config_Templaza_Image extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Templaza_Image constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'templaza-image';
			self::$name = esc_html__( 'TemPlaza: Image', 'templaza-elements' );
			self::$desc = esc_html__( 'Display Image.', 'templaza-elements' );
			self::$icon = 'eicon-image';
			parent::__construct();
		}

		/**
		 * @return array
		 */
		public function get_options() {
			// options
			return array(
                array(
                    'type'      => Controls_Manager::MEDIA,
                    'name'      => 'templaza_image',
                    'label'     => esc_html__( 'Image', 'templaza-elements' ),
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),
                ),
                array(
                    'type'      => Controls_Manager::SWITCHER,
                    'name'      => 'parallax_enable',
                    'label'     => esc_html__( 'Enable parallax', 'templaza-elements' ),
                    'start_section' => 'parallax-options',
                    'section_name'  => esc_html__( 'Parallax options', 'templaza-elements' ),
                ),
                array(
                    'type'      => Controls_Manager::TEXT,
                    'name'      => 'parallax_x',
                    'label'     => esc_html__( 'Animate translateX', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Parallax options', 'templaza-elements' ),
                    'condition'     => array('parallax_enable' => 'yes'),
                ),
                array(
                    'type'      => Controls_Manager::TEXT,
                    'name'      => 'parallax_y',
                    'label'     => esc_html__( 'Animate translateY', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Parallax options', 'templaza-elements' ),
                    'condition'     => array('parallax_enable' => 'yes'),
                ),
                array(
                    'type'      => Controls_Manager::TEXT,
                    'name'      => 'parallax_scaling',
                    'label'     => esc_html__( 'Animate scaling', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Parallax options', 'templaza-elements' ),
                    'condition'     => array('parallax_enable' => 'yes'),
                ),
                array(
                    'type'      => Controls_Manager::TEXT,
                    'name'      => 'parallax_opacity',
                    'label'     => esc_html__( 'Animate the opacity', 'templaza-elements' ),
                    'start_section' => 'parallax-options',
                    'section_name'  => esc_html__( 'Parallax options', 'templaza-elements' ),
                    'condition'     => array('parallax_enable' => 'yes'),
                ),
                array(
                    'type'      => Controls_Manager::TEXT,
                    'name'      => 'parallax_blur',
                    'label'     => esc_html__( 'Animate the blur filter', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Parallax options', 'templaza-elements' ),
                    'condition'     => array('parallax_enable' => 'yes'),
                ),
                array(
                    'type'          => Group_Control_Box_Shadow::get_type(),
                    'name'          => 'box_shadow',
                    'label'         => esc_html__('Box shadow', 'templaza-elements'),
                    'selector'      => '{{WRAPPER}} .templaza-image',
                    'start_section' => 'style',
                    'section_tab'   => Controls_Manager::TAB_STYLE,
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),

                ),

			);
		}

        public function get_template_name() {
            return 'base';
        }
	}
}