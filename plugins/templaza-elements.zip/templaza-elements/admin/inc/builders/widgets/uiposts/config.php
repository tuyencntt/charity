<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIPosts' ) ) {
	/**
	 * Class Templaza_Elements_Config_UIPosts
	 */
	class Templaza_Elements_Config_UIPosts extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uiposts';
			self::$name = esc_html__( 'TemPlaza: UI Posts', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Posts Box.', 'templaza-elements' );
			self::$icon = 'eicon-posts-grid';
			self::$assets_path  =   plugin_dir_url(__FILE__). 'assets/';
			parent::__construct();
		}

		public function get_scripts() {
			return array(
				'ui-post-loadmore' => array(
					'src'   =>  'script.min.js',
					'deps'  =>  array('jquery')
				)
			);
		}

		public function get_localize() {
			global $wp_query;
			// get settings
			return array(
				'ui_post_loadmore_params'   =>  array(
					'ajaxurl' => site_url() . '/wp-admin/admin-ajax.php', // WordPress AJAX
					'posts' => json_encode( $wp_query->query_vars ), // everything about your loop is here
					'current_page' => get_query_var( 'paged' ) ? get_query_var('paged') : 1,
					'max_page' => $wp_query->max_num_pages,
				)
			);
		}

		/**
		 * @return array
		 */
		public function get_options() {
			// options
			$options = array(
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'resource',
					'label'         => esc_html__( 'Choose Resource', 'templaza-elements' ),
					'options'       => array(
						'post'      => __('Post', 'templaza-elements'),
						'portfolio' => __('Portfolio', 'templaza-elements'),
					),
					'default'       => 'post',
					'description'   => esc_html__( 'Select a content resource from the list. if you choose Portfolio then you must have to installed Portfolio post type.', 'templaza-elements' ),
				),
				array(
					'type'          => Controls_Manager::SELECT2,
					'id'            => 'post_category',
					'label'         => esc_html__( 'Select Category', 'templaza-elements' ),
					'options'       => Templaza_Elements_Builders_Helper::get_cat_taxonomy( 'category' ),
					'multiple'      => true,
					'conditions' => [
						'terms' => [
							['name' => 'resource', 'operator' => '===', 'value' => 'post'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT2,
					'id'            => 'portfolio_category',
					'label'         => esc_html__( 'Select Category', 'templaza-elements' ),
					'options'       => Templaza_Elements_Builders_Helper::get_cat_taxonomy( 'portfolio-category'),
					'multiple'      => true,
					'conditions' => [
						'terms' => [
							['name' => 'resource', 'operator' => '===', 'value' => 'portfolio'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'include_subcagories',
					'label'         => esc_html__('Include subcagories', 'templaza-elements'),
					'description'   => esc_html__( 'Select yes to include sub categories', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '0',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'ordering',
					'label'         => esc_html__( 'Ordering', 'templaza-elements' ),
					'options'       => array(
						'latest'    => __('Latest', 'templaza-elements'),
						'oldest'    => __('Oldest', 'templaza-elements'),
						'popular'   => __('Popular', 'templaza-elements'),
						'sticky'   => __('Sticky Only', 'templaza-elements'),
						'random'    => __('Random', 'templaza-elements'),
					),
					'default'       => 'latest',
					'description'   => esc_html__( 'Select articles ordering from the list.', 'templaza-elements' ),
				),
				array(
					'type'          => Controls_Manager::NUMBER,
					'id'            => 'limit',
					'label'         => esc_html__( 'Limit', 'templaza-elements' ),
					'description'   => esc_html__( 'Set the number of articles you want to display.', 'templaza-elements' ),
					'min' => 1,
					'max' => 90,
					'step' => 1,
					'default' => 3,
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'ajax_loading_paging',
					'label'         => esc_html__('Ajax load Paging', 'templaza-elements'),
					'description'   => esc_html__( 'Select yes to enable Ajax load paging. Note: This option is run for only one UI Post per page.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '0',
				),
				array(
					'id'          => 'large_desktop_columns',
					'label' => __( 'Large Desktop Columns', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'options'       => array(
						'1'    => __('1 Column', 'templaza-elements'),
						'2'    => __('2 Columns', 'templaza-elements'),
						'3'    => __('3 Columns', 'templaza-elements'),
						'4'    => __('4 Columns', 'templaza-elements'),
						'5'    => __('5 Columns', 'templaza-elements'),
						'6'    => __('6 Columns', 'templaza-elements'),
					),
					'default'   => '3',
					'separator'     => 'before',
				),
				array(
					'id'          => 'desktop_columns',
					'label' => __( 'Desktop Columns', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'options'       => array(
						'1'    => __('1 Column', 'templaza-elements'),
						'2'    => __('2 Columns', 'templaza-elements'),
						'3'    => __('3 Columns', 'templaza-elements'),
						'4'    => __('4 Columns', 'templaza-elements'),
						'5'    => __('5 Columns', 'templaza-elements'),
						'6'    => __('6 Columns', 'templaza-elements'),
					),
					'default'   => '3',
				),
				array(
					'id'          => 'laptop_columns',
					'label' => __( 'Laptop Columns', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'options'       => array(
						'1'    => __('1 Column', 'templaza-elements'),
						'2'    => __('2 Columns', 'templaza-elements'),
						'3'    => __('3 Columns', 'templaza-elements'),
						'4'    => __('4 Columns', 'templaza-elements'),
						'5'    => __('5 Columns', 'templaza-elements'),
						'6'    => __('6 Columns', 'templaza-elements'),
					),
					'default'   => '3'
				),
				array(
					'id'          => 'tablet_columns',
					'label' => __( 'Tablet Columns', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'options'       => array(
						'1'    => __('1 Column', 'templaza-elements'),
						'2'    => __('2 Columns', 'templaza-elements'),
						'3'    => __('3 Columns', 'templaza-elements'),
						'4'    => __('4 Columns', 'templaza-elements'),
						'5'    => __('5 Columns', 'templaza-elements'),
						'6'    => __('6 Columns', 'templaza-elements'),
					),
					'default'   => '2'
				),
				array(
					'id'          => 'mobile_columns',
					'label' => __( 'Mobile Columns', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'options'       => array(
						'1'    => __('1 Column', 'templaza-elements'),
						'2'    => __('2 Columns', 'templaza-elements'),
						'3'    => __('3 Columns', 'templaza-elements'),
						'4'    => __('4 Columns', 'templaza-elements'),
						'5'    => __('5 Columns', 'templaza-elements'),
						'6'    => __('6 Columns', 'templaza-elements'),
					),
					'default'   => '1'
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'column_grid_gap',
					'label'         => esc_html__('Column Gap', 'templaza-elements'),
					'description'   => esc_html__('Modified Gap Column', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'collapse' => __('Collapse', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'color_mode',
					'label'         => esc_html__( 'Color Mode', 'templaza-elements' ),
					'options'       => array(
						'dark'      => __('Dark', 'templaza-elements'),
						'light' => __('Light', 'templaza-elements'),
					),
					'default'       => 'dark',
					'separator'     => 'before',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'masonry',
					'label'         => esc_html__('Enable Masonry', 'templaza-elements'),
					'description'   => esc_html__( 'Select yes to enable Masonry Grid.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '0',
				),

				//Card Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_style',
					'label' => __( 'Card Style', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('None', 'templaza-elements'),
						'default' => __('Card Default', 'templaza-elements'),
						'primary' => __('Card Primary', 'templaza-elements'),
						'secondary' => __('Card Secondary', 'templaza-elements'),
						'hover' => __('Card Hover', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
					'start_section' => 'card_settings',
					'section_name'      => esc_html__('Card Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background',
					'label'         => esc_html__('Card Background', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .uk-card' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color',
					'label'         => esc_html__('Card Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .uk-card' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'card_size',
					'label' => __( 'Card Size', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
				),
				array(
					'type'          => Controls_Manager::DIMENSIONS,
					'name'          =>  'card_padding',
					'label'         => __( 'Card Padding', 'templaza-elements' ),
					'responsive'    =>  true,
					'size_units'    => [ 'px', 'em', '%' ],
					'selectors'     => [
						'{{WRAPPER}} .ui-post-info-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_size', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),

				//Filter Settings
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'use_filter',
					'label'         => esc_html__('Use Filter', 'templaza-elements'),
					'description'   => esc_html__( 'Display filter articles', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'start_section' => 'filter_settings',
					'section_name'  => esc_html__('Filter Settings', 'templaza-elements')
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_position',
					'label' => __( 'Filter Position', 'templaza-elements' ),
					'default' => 'top',
					'options' => [
						'top' => __('Top', 'templaza-elements'),
						'left' => __('Left', 'templaza-elements'),
						'right' => __('Right', 'templaza-elements'),
					],
				),
				array(
					'id'            => 'filter_width',
					'label'         => __( 'Filter Width', 'templaza-elements' ),
					'type'          => Controls_Manager::SLIDER,
					'devices'       => [ 'desktop', 'tablet', 'mobile' ],
					'responsive'    => true,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 1000,
							'step'=> 1,
						],
					],
					'desktop_default' => [
						'size' => 250,
						'unit' => 'px',
					],
					'tablet_default' => [
						'size' => 250,
						'unit' => 'px',
					],
					'mobile_default' => [
						'size' => 250,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .ui-post-filter' => 'width: {{SIZE}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'filter_position', 'operator' => '!==', 'value' => 'top'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT2,
					'id'            => 'filter_type',
					'label' => __( 'Filter Type', 'templaza-elements' ),
					'default' => 'tag',
					'multiple' => true,
					'options' => [
						'tag' => __('Tags', 'templaza-elements'),
						'category' => __('Categories', 'templaza-elements'),
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_grid_gap',
					'label'         => esc_html__('Filter Gap', 'templaza-elements'),
					'description'   => esc_html__('Modified Filter Gap Column', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'collapse' => __('Collapse', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'filter_position', 'operator' => '!==', 'value' => 'top'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'use_filter_sort',
					'label'         => esc_html__('Use Filter Sort', 'templaza-elements'),
					'description'   => esc_html__( 'Display filter sort', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'display_filter_header',
					'label'         => esc_html__('Display Header', 'templaza-elements'),
					'description'   => esc_html__( 'Whether display filter header', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '1',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_container',
					'label'         => esc_html__('Filter Container', 'templaza-elements'),
					'description'   => esc_html__('Add the uk-container class to widget to give it a max-width and wrap the main content', 'templaza-elements'),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'default' => __('Default', 'templaza-elements'),
						'xsmall' => __('X-Small', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'expand' => __('Expand', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'filter_position', 'operator' => '===', 'value' => 'top'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'filter_block_align',
					'label'         => esc_html__('Block Alignment', 'templaza-elements'),
					'description'   => esc_html__('Define the alignment in case the container exceeds the element\'s max-width.', 'templaza-elements'),
					'options'       => array(
						''=>__('Left', 'templaza-elements'),
						'center'=>__('Center', 'templaza-elements'),
						'right'=>__('Right', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'filter_container', 'operator' => '!==', 'value' => ''],
							['name' => 'filter_position', 'operator' => '===', 'value' => 'top'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'filter_block_align_breakpoint',
					'label'         => esc_html__('Block Alignment Breakpoint', 'templaza-elements'),
					'description'   => esc_html__('Define the device width from which the alignment will apply.', 'templaza-elements'),
					'options'       => array(
						''=>__('Always', 'templaza-elements'),
						's'=>__('Small (Phone Landscape)', 'templaza-elements'),
						'm'=>__('Medium (Tablet Landscape)', 'templaza-elements'),
						'l'=>__('Large (Desktop)', 'templaza-elements'),
						'xl'=>__('X-Large (Large Screens)', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'filter_position', 'operator' => '===', 'value' => 'top'],
							['name' => 'filter_container', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'filter_block_align_fallback',
					'label'         => esc_html__('Block Alignment Fallback', 'templaza-elements'),
					'description'   => esc_html__('Define the alignment in case the container exceeds the element\'s max-width.', 'templaza-elements'),
					'options'       => array(
						''=>__('Left', 'templaza-elements'),
						'center'=>__('Center', 'templaza-elements'),
						'right'=>__('Right', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'filter_position', 'operator' => '===', 'value' => 'top'],
							['name' => 'filter_container', 'operator' => '!==', 'value' => ''],
							['name' => 'filter_block_align_breakpoint', 'operator' => '!==', 'value' => ''],
						],
					],

				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_text_alignment',
					'label' => __( 'Text Alignment', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'left' => __('Left', 'templaza-elements'),
						'center' => __('Center', 'templaza-elements'),
						'right' => __('Right', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'filter_text_alignment_breakpoint',
					'label'         => esc_html__('Text Alignment Breakpoint', 'templaza-elements'),
					'description'   => esc_html__('Display the button alignment only on this device width and larger', 'templaza-elements'),
					'options'       => array(
						'' => __('Always', 'templaza-elements'),
						's' => __('Small (Phone Landscape)', 'templaza-elements'),
						'm' => __('Medium (Tablet Landscape)', 'templaza-elements'),
						'l' => __('Large (Desktop)', 'templaza-elements'),
						'xl' => __('X-Large (Large Screens)', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'filter_text_alignment', 'operator' => '!==', 'value' => ''],
						],
					],

				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'filter_text_alignment_fallback',
					'label'         => esc_html__('Text Alignment Fallback', 'templaza-elements'),
					'description'   => esc_html__('Define an alignment fallback for device widths below the breakpoint.', 'templaza-elements'),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'left' => __('Left', 'templaza-elements'),
						'center' => __('Center', 'templaza-elements'),
						'right' => __('Right', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'filter_text_alignment', 'operator' => '!==', 'value' => ''],
							['name' => 'filter_text_alignment_breakpoint', 'operator' => '!==', 'value' => ''],
						],
					],

				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_animate',
					'label'         => __( 'Filter Animate', 'templaza-elements' ),
					'options'       => array(
						'slide'     => __('Slide', 'templaza-elements'),
						'fade'      => __('Fade', 'templaza-elements'),
						'delayed-fade'    => __('Delayed Fade', 'templaza-elements'),
					),
					'default'       => 'slide',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_margin',
					'label'         => esc_html__('Margin Bottom', 'templaza-elements'),
					'description'   => esc_html__('Set the bottom margin.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove-vertical' => __('None', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'filter_position', 'operator' => '===', 'value' => 'top'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'filter_visibility',
					'label'         => esc_html__('Visibility', 'templaza-elements'),
					'description'   => esc_html__('Display the element only on this device width and larger.', 'templaza-elements'),
					'options'       => array(
						'' => __('Always', 'templaza-elements'),
						'@s' => __('Small (Phone Landscape)', 'templaza-elements'),
						'@m' => __('Medium (Tablet Landscape)', 'templaza-elements'),
						'@l' => __('Large (Desktop)', 'templaza-elements'),
						'@xl' => __('X-Large (Large Screens)', 'templaza-elements'),
					),
					'default'           => '',
				),

				//Slider Settings
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'use_slider',
					'label'         => esc_html__('Display Articles as Slider', 'templaza-elements'),
					'description'   => esc_html__( 'Display Articles as Carousel Slider', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'start_section' => 'slider_settings',
					'section_name'  => esc_html__('Slider Settings', 'templaza-elements')
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'enable_navigation',
					'label'         => esc_html__('Navigation', 'templaza-elements'),
					'description'   => esc_html__( 'Enable Navigation', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '1',
					'conditions' => [
						'terms' => [
							['name' => 'use_slider', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'navigation_position',
					'label' => __( 'Navigation Position', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('Outside', 'templaza-elements'),
						'inside' => __('Inside', 'templaza-elements'),
					],
					'conditions' => [
						'terms' => [
							['name' => 'use_slider', 'operator' => '===', 'value' => '1'],
							['name' => 'enable_navigation', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'enable_dotnav',
					'label'         => esc_html__('Dot Navigation', 'templaza-elements'),
					'description'   => esc_html__( 'Enable Dot Navigation', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '1',
					'conditions' => [
						'terms' => [
							['name' => 'use_slider', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'center_slider',
					'label'         => esc_html__('Center Slider', 'templaza-elements'),
					'description'   => esc_html__( 'To center the list items', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'conditions' => [
						'terms' => [
							['name' => 'use_slider', 'operator' => '===', 'value' => '1'],
						],
					],
				),

				//Title configure
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_tag',
					'label'         => esc_html__( 'Title tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
					),
					'default'       => 'h3',
					'description'   => esc_html__( 'Choose heading element.', 'templaza-elements' ),
					'start_section' => 'title_settings',
					'section_name'      => esc_html__('Title Settings', 'templaza-elements')
				),
				array(
					'name'            => 'title_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-title',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_heading_style',
					'default'       => 'h3',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Heading styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
					),
				),
				array(
					'id'            => 'custom_title_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-title > a' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'title_margin',
					'label'         => esc_html__('Title Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the title margin.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove-vertical' => __('None', 'templaza-elements'),
					),
					'default'           => '',
				),

				// Image Settings
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'hide_thumbnail',
					'label'         => esc_html__('Hide Thumbnail', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to hide article thumbnail.', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'start_section' => 'image_settings',
					'section_name'  => esc_html__('Image Settings', 'templaza-elements')
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'layout',
					'label' => __( 'Layout', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements'),
						'thumbnail' => __('Thumbnail', 'templaza-elements')
					],
					'conditions' => [
						'terms' => [
							['name' => 'hide_thumbnail', 'operator' => '!==', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'thumbnail_hover',
					'label'         => esc_html__('Content display on hover', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to enable on hover content article with thumbnail.', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'conditions' => [
						'terms' => [
							['name' => 'layout', 'operator' => '===', 'value' => 'thumbnail'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'thumbnail_hover_transition',
					'label' => __( 'Hover Transition', 'templaza-elements' ),
					'default' => 'fade',
					'options' => [
						'fade' => __('Fade', 'templaza-elements'),
						'scale-up' => __('Scale Up', 'templaza-elements'),
						'scale-down' => __('Scale Down', 'templaza-elements'),
						'slide-top' => __('Slide Top', 'templaza-elements'),
						'slide-bottom' => __('Slide Bottom', 'templaza-elements'),
						'slide-left' => __('Slide Left', 'templaza-elements'),
						'slide-right' => __('Slide Right', 'templaza-elements'),
						'slide-top-small' => __('Slide Top Small', 'templaza-elements'),
						'slide-bottom-small' => __('Slide Bottom Small', 'templaza-elements'),
						'slide-left-small' => __('Slide Left Small', 'templaza-elements'),
						'slide-right-small' => __('Slide Right Small', 'templaza-elements'),
						'slide-top-medium' => __('Slide Top Medium', 'templaza-elements'),
						'slide-bottom-medium' => __('Slide Bottom Medium', 'templaza-elements'),
						'slide-left-medium' => __('Slide Left Medium', 'templaza-elements'),
						'slide-right-medium' => __('Slide Right Medium', 'templaza-elements'),
					],
					'conditions' => [
						'terms' => [
							['name' => 'thumbnail_hover', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'image_position',
					'label'         => esc_html__( 'Image Position', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s position.', 'templaza-elements' ),
					'options'       => array(
						'top' => __('Top', 'templaza-elements'),
						'inside' => __('Inside Body', 'templaza-elements'),
					),
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'layout', 'operator' => '===', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'cover_image',
					'label'         => esc_html__('Cover Image', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to display image cover.', 'templaza-elements' ),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'name'            => 'thumbnail_height',
					'label'         => __( 'Thumbnail Height', 'templaza-elements' ),
					'type'          => Controls_Manager::SLIDER,
					'devices'       => [ 'desktop', 'tablet', 'mobile' ],
					'responsive'    => true,
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 1000
						],
					],
					'desktop_default' => [
						'size' => 220,
						'unit' => 'px',
					],
					'tablet_default' => [
						'size' => 220,
						'unit' => 'px',
					],
					'mobile_default' => [
						'size' => 220,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .tz-image-cover' => 'height: {{SIZE}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'cover_image', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'image_border',
					'label'         => esc_html__( 'Border', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s border style.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-border-circle' => __('Circle', 'templaza-elements'),
						'uk-border-rounded' => __('Rounded', 'templaza-elements'),
						'uk-border-pill' => __('Pill', 'templaza-elements'),
					),
					'default'       => '',
				),
				array(
					'type'          => \Elementor\Group_Control_Image_Size::get_type(),
					'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [ 'custom' ],
					'include' => [],
					'default' => 'large'
				),

				//Content style
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'show_introtext',
					'label'         => esc_html__('Show Introtext', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to show instrotext.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '1',
					'start_section' => 'content_settings',
					'section_name'  => esc_html__('Content Settings', 'templaza-elements')
				),
				array(
					'name'          => 'content_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-post-introtext',
				),
				array(
					'id'            => 'content_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-post-introtext' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'show_author',
					'label'         => esc_html__('Show Author', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to show author.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '1',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'show_category',
					'label'         => esc_html__('Show Category', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to show category.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '1',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'show_date',
					'label'         => esc_html__('Show Date', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to show date.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '1',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'show_tags',
					'label'         => esc_html__('Show Tags', 'templaza-elements'),
					'description'   => esc_html__( 'Whether to show tags.', 'templaza-elements' ),
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '0',
				),
				array(
					'id'    => 'tag_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Tag Style', 'templaza-elements'),
					'description' => __('Select a predefined tag style.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'plain-text' => __('Plain Text', 'templaza-elements'),
					),
					'default' => '',
					'conditions' => [
						'terms' => [
							['name' => 'show_tags', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'tag_margin',
					'label'         => esc_html__('Tag Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the tag margin.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove-vertical' => __('None', 'templaza-elements'),
					),
					'default'           => '',
					'conditions' => [
						'terms' => [
							['name' => 'show_tags', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'content_dropcap',
					'label'         => esc_html__('Drop Cap', 'templaza-elements'),
					'description'   => __('Display the first letter of the paragraph as a large initial.', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),

				//Button settings
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'show_readmore',
					'label'         => esc_html__('Show Readmore', 'templaza-elements'),
					'description'   => __('Display the first letter of the paragraph as a large initial.', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'start_section' => 'button_settings',
					'section_name'      => esc_html__('Button Settings', 'templaza-elements')
				),
				array(
					'id'    => 'all_button_title',
					'label' => __( 'Text', 'templaza-elements' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Read more' , 'templaza-elements' ),
					'label_block' => true,
				),
				array(
					'id'    => 'target',
					'type' => Controls_Manager::SELECT,
					'label' => __('Link New Tab', 'templaza-elements'),
					'options' => array(
						'' => __('Same Window', 'templaza-elements'),
						'_blank' => __('New Window', 'templaza-elements'),
					),
				),
				array(
					'id'    => 'button_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Set the button style.', 'templaza-elements'),
					'options' => array(
						'' => __('Button Default', 'templaza-elements'),
						'primary' => __('Button Primary', 'templaza-elements'),
						'secondary' => __('Button Secondary', 'templaza-elements'),
						'danger' => __('Button Danger', 'templaza-elements'),
						'text' => __('Button Text', 'templaza-elements'),
						'link' => __('Link', 'templaza-elements'),
						'link-muted' => __('Link Muted', 'templaza-elements'),
						'link-text' => __('Link Text', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'name'          => 'button_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Button Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-post-button',
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_background',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Background Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-post-button' => 'background-color: {{VALUE}}',
					],
					'separator'     => 'before',
					'default' => '#1e87f0',
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Button Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-post-button' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'name'            => 'button_border',
					'type'          =>  \Elementor\Group_Control_Border::get_type(),
					'label' => __( 'Button Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-post-button',
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'id'            => 'button_background_hover',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Hover Background Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-post-button:hover' => 'background-color: {{VALUE}}',
					],
					'default' => '#0f7ae5',
					'separator'     => 'before',
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_hover_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Hover Button Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-post-button:hover' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'name'            => 'button_border_hover',
					'type'          =>  \Elementor\Group_Control_Border::get_type(),
					'label' => __( 'Button Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-post-button:hover',
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'id'    => 'button_size',
					'type' => Controls_Manager::SELECT,
					'label' => __('Button Size', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'uk-button-small' => __('Small', 'templaza-elements'),
						'uk-button-large' => __('Large', 'templaza-elements'),
					),
					'separator'     => 'before',
				),
				array(
					'id'    => 'button_shape',
					'label' => __( 'Button Shape', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'rounded',
					'options' => [
						'rounded' => __('Rounded', 'templaza-elements' ),
						'square' => __('Square', 'templaza-elements' ),
						'round' => __('Round', 'templaza-elements' ),
					],
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-muted'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-text'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'text'],
						],
					],
				),
				array(
					'id'    => 'button_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}