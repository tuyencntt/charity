<?php
defined( 'ABSPATH' ) || exit;
//Get Item Tags
$tags = wp_get_post_terms( $item->ID , $resource. '_tag' );
$i = 1;
$tag_content    =   '';
$tag_slugs      =   array();
if($tags){
	foreach ( $tags as $term ) {
		$tag_link = get_term_link( $term, array( $resource. '_tag' ) );
		if( is_wp_error( $tag_link ) )
			continue;
		$tag_slugs[]    =   $term -> slug;
		if ($tag_style == 'plain-text') {
			if($i < count($tags)){
				if ( $i == count($tags) - 1 ) {
					$tag_content .= esc_attr($term->name.' & ');
				} else {
					$tag_content .= esc_attr($term->name.', ');
				}
			} else {
				$tag_content .= esc_attr($term->name);
			}
		} else {
			$tag_content    .=  '<div><a href="'.esc_url($tag_link).'">#'.esc_attr($term->name).'</a></div>';
		}
		$i++;
	}
	$tag_content    =   $tag_style == '' ? '<div class="uk-grid-small" data-uk-grid>'.$tag_content.'</div>' : $tag_content;
}

//Category
$categories = $resource == 'post' ? wp_get_post_terms( $item->ID , 'category' ) : wp_get_post_terms( $item->ID , $resource.'-category' );
// init counter
$cats  =   array();
$cat_content    =   '';
$cat_slugs      =   array();
if ($categories && count($categories)) {
	foreach ( $categories as $term ) {
		$term_link = $resource == 'post' ? get_term_link( $term, 'category' ) : get_term_link( $term, $resource.'-category' );
		if( is_wp_error( $term_link ) )
			continue;
		$cat_slugs[]    =   $term->slug;
		$cats[]         =   '<a href="'.esc_url($term_link).'">'.esc_attr($term->name).'</a>';
	}
	$cat_content     =  implode(', ', $cats);
}

$output .=  '<article data-tag="'.implode(' ', $tag_slugs).'" data-cat="'.implode(' ', $cat_slugs).'" data-date="'.esc_attr(get_the_date('Y-m-d', $item)).'" data-hits="'.esc_attr(get_post_meta($item->ID, 'post_views_count', true)).'">';
$output .= '<div class="uk-article uk-card'.$card_style.$card_size_cls.( $thumbnail_hover ? ' uk-transition-toggle uk-overflow-hidden' : '' ).'">';
if (!$hide_thumbnail && has_post_thumbnail( $item->ID ) && $image_position == 'top' ):
	$output .=  '<a class="uk-display-block uk-card-media-top'.$cover_image.$image_border.'" href="'. get_permalink( $item->ID ) .'">'. wp_get_attachment_image(get_post_thumbnail_id( $item->ID ), $thumbnail_size) .'</a>';
endif;
if ($layout == 'thumbnail') {
	$output .= '<a href="'. get_permalink( $item->ID ) .'"><div class="uk-position-cover uk-overlay uk-overlay-primary'.( $thumbnail_hover ? ' uk-transition-fade' : '' ).'"></div></a>';
}

$output .= '<div class="ui-post-info-wrap'.$uk_card_body.($layout == 'thumbnail' ? ' uk-position-bottom uk-light' : '').( $thumbnail_hover && $thumbnail_hover_transition ? $thumbnail_hover_transition : '' ).'">';

if (!$hide_thumbnail && has_post_thumbnail( $item->ID ) && $image_position == 'inside' ):
	$output .=  '<a class="uk-display-block'.$cover_image.$image_border.'" href="'. get_permalink( $item->ID ) .'">'. wp_get_attachment_image(get_post_thumbnail_id( $item->ID ), $thumbnail_size) .'</a>';
endif;

$output .= '<'.$heading_selector.' class="ui-title'.$title_heading_style.$title_margin.'"><a href="'. get_permalink( $item->ID ) .'">' . $item->post_title . '</a></'.$heading_selector.'>';

if($show_author || $show_category || $show_date) {
	$output .= '<div class="uk-article-meta uk-grid-small uk-margin" data-uk-margin data-uk-grid>';

	if($show_date) {
		$output .= '<span class="ui-post-meta-date">' . get_the_date('', $item) . '</span>';
	}

	if($show_category) {
		if ($resource == 'post') {
			$output .= '<span class="ui-post-meta-category">' . get_the_category_list(', ', '', $item->ID) . '</span>';
		} else {
			if ($categories && count($categories)) {
				$output     .=  '<span class="ui-post-meta-category">';
				$output     .=  $cat_content;
				$output     .=  '</span>';
			}
		}
	}
	if($show_author) {
		$authordata = get_userdata( $item->post_author );
		$link = sprintf(
			'<a href="%1$s" title="%2$s" rel="author">%3$s</a>',
			esc_url( get_author_posts_url( $item->post_author ) ),
			/* translators: %s: Author's display name. */
			esc_attr( sprintf( __( 'Posts by %s' ), $authordata->display_name ) ),
			$authordata->display_name
		);
		$output .= '<span class="ui-post-meta-author">' . $link . '</span>';
	}
	$output .= '</div>';
}

if ($show_intro && $item->post_excerpt) {
	$output .= '<div class="ui-post-introtext'.$dropcap.'">'. $item->post_excerpt .'</div>';
}

if ($show_tags) {
	if($tags){
		$output .= '<div class="ui-post-tags uk-article-meta'.$tag_margin.'">'. $tag_content .'</div>';
	}
}

if($show_readmore) {
	$output .= '<a class="ui-post-button' . $button_class . '" href="'. get_permalink( $item->ID ) .'"'.$button_target.'>'. $button_text .'</a>';
}
$output .= '</div>'; //.ui-post-article-info-wrap
$output .=  '</div>';
$output .=  '</article>';