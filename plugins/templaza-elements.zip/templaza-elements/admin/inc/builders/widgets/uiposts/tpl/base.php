<?php
defined( 'ABSPATH' ) || exit;
$_is_elementor  = (isset($args['page_builder']) && $args['page_builder'] == 'elementor')?true:false;

$layout         = (isset($instance['layout'] ) && $instance['layout'] ) ? $instance['layout'] : '';
$color_mode     = (isset($instance['color_mode'] ) && $instance['color_mode'] ) ? ' uk-'. $instance['color_mode'] : '';
$ajax_loading   = (isset($instance['ajax_loading_paging']) && $instance['ajax_loading_paging']) ? intval($instance['ajax_loading_paging']) : 0;
$masonry        = (isset($instance['masonry']) && $instance['masonry']) ? intval($instance['masonry']) : 0;

//Get posts
$limit          = ( isset( $instance['limit'] ) && $instance['limit'] ) ? $instance['limit'] : 4;
$resource       = ( isset( $instance['resource'] ) && $instance['resource'] ) ? $instance['resource'] : 'post';
$ordering       = ( isset( $instance['ordering'] ) && $instance['ordering'] ) ? $instance['ordering'] : 'latest';
if ($resource == 'post') {
	$category   = ( isset( $instance['post_category'] ) && $instance['post_category'] ) ? $instance['post_category'] : array('0');
} else {
	$category   = ( isset( $instance['portfolio_category'] ) && $instance['portfolio_category'] ) ? $instance['portfolio_category'] : array('0');
}
$options_query = array();
switch ($ordering) {
	case 'latest':
		$options_query['orderby'] = 'date';
		$options_query['order'] = 'DESC';
		break;
	case 'oldest':
		$options_query['orderby'] = 'date';
		$options_query['order'] = 'ASC';
		break;
	case 'random':
		$options_query['orderby'] = 'rand';
		break;
	case 'popular':
		$options_query['orderby'] = 'meta_value_num';
		$options_query['order'] = 'DESC';
		$options_query['meta_key'] = 'post_views_count';
		break;
	case 'sticky':
		$options_query['post__in'] = get_option( 'sticky_posts' );
		$options_query['ignore_sticky_posts'] = 1;
		break;
}
if ($resource == 'post') {
	$options_query['category']  =   implode(',', $category);
} else {
	if (count($category) && $category[0] != '0') {
		$options_query['tax_query'] =   array(
			array(
				'taxonomy' => $resource.'-category',
				'field' => 'id',
				'operator' => 'IN',
				'terms' => $category,
			)
		);
	}
}
$query_args = array(
	'post_type'         => $resource,
	'posts_per_page'    => $limit,
);
$query_args =   array_merge($query_args, $options_query);
$posts      =   get_posts($query_args);
wp_reset_postdata();
//responsive width
$large_desktop_columns    = ( isset( $instance['large_desktop_columns'] ) && $instance['large_desktop_columns'] ) ? $instance['large_desktop_columns'] : '4';
$desktop_columns    = ( isset( $instance['desktop_columns'] ) && $instance['desktop_columns'] ) ? $instance['desktop_columns'] : '4';
$laptop_columns     = ( isset( $instance['laptop_columns'] ) && $instance['laptop_columns'] ) ? $instance['laptop_columns'] : '3';
$tablet_columns     = ( isset( $instance['tablet_columns'] ) && $instance['tablet_columns'] ) ? $instance['tablet_columns'] : '2';
$mobile_columns     = ( isset( $instance['mobile_columns'] ) && $instance['mobile_columns'] ) ? $instance['mobile_columns'] : '1';
$column_grid_gap    = ( isset( $instance['column_grid_gap'] ) && $instance['column_grid_gap'] ) ? ' uk-grid-'. $instance['column_grid_gap'] : '';

//Card size
$card_style 	= (isset($instance['card_style']) && $instance['card_style']) ? ' uk-card-'. $instance['card_style'] : '';
$card_size 		= (isset($instance['card_size']) && $instance['card_size']) ? $instance['card_size'] : '';
$card_size_cls  = $card_size ? ' uk-card-'.$card_size : '';
$uk_card_body   = $card_size != 'none' ? ' uk-card-body' : '';

//Title
$heading_selector = (isset($instance['title_tag']) && $instance['title_tag']) ? $instance['title_tag'] : 'h3';
$title_heading_style    = (isset($instance['title_heading_style']) && $instance['title_heading_style']) ? ' uk-'. $instance['title_heading_style'] : '';
$title_margin   = (isset($instance['title_margin']) && $instance['title_margin']) ? ' uk-margin-'. $instance['title_margin'] .'-bottom' : ' uk-margin-bottom';

//Image
$hide_thumbnail = (isset($instance['hide_thumbnail']) && $instance['hide_thumbnail']) ? intval($instance['hide_thumbnail']) : 0;
$thumbnail_size = (isset($instance['thumbnail_size']) && $instance['thumbnail_size']) ? $instance['thumbnail_size'] : 'full';
$image_position = (isset($instance['image_position']) && $instance['image_position']) ? $instance['image_position'] : 'top';
$image_border   = (isset($instance['image_border']) && $instance['image_border']) ? ' uk-overflow-hidden '. $instance['image_border'] : '';
$thumbnail_hover= (isset($instance['thumbnail_hover']) && $instance['thumbnail_hover']) ? intval($instance['thumbnail_hover']) : 0;
$thumbnail_hover_transition= (isset($instance['thumbnail_hover_transition']) && $instance['thumbnail_hover_transition']) ? ' uk-transition-'. $instance['thumbnail_hover_transition'] : '';
$cover_image    = (isset($instance['cover_image']) && $instance['cover_image']) ? intval($instance['cover_image']) : 0;
$cover_image    =   $cover_image ? ' tz-image-cover' : '';

$show_intro 	= (isset($instance['show_introtext']) && $instance['show_introtext']) ? intval($instance['show_introtext']) : 0;
$dropcap        = (isset($instance['content_dropcap']) && $instance['content_dropcap']) ? ' uk-dropcap' : '';
$show_author 	= (isset($instance['show_author']) && $instance['show_author']) ? intval($instance['show_author']) : 0;
$show_category 	= (isset($instance['show_category']) && $instance['show_category']) ? intval($instance['show_category']) : 0;
$show_date 		= (isset($instance['show_date']) && $instance['show_date']) ? intval($instance['show_date']) : 0;
$show_tags 		= (isset($instance['show_tags']) && $instance['show_tags']) ? intval($instance['show_tags']) : 0;
$tag_style 		= (isset($instance['tag_style']) && $instance['tag_style']) ? $instance['tag_style'] : '';
$tag_margin 	= (isset($instance['tag_margin']) && $instance['tag_margin']) ? ' uk-margin-'. $instance['tag_margin'] : ' uk-margin';

$show_readmore 	= (isset($instance['show_readmore']) && $instance['show_readmore']) ? intval($instance['show_readmore']) : 0;
$button_text    = (isset($instance['all_button_title']) && $instance['all_button_title']) ? $instance['all_button_title'] : 'Read More';
$button_target  = (isset($instance['target']) && $instance['target']) ? ' target="'. $instance['target'] .'"' : '';
$button_class   = (isset($instance['button_style']) && $instance['button_style']) ? ' uk-button uk-button-' . $instance['button_style'] : ' uk-button uk-button-default';
$button_class   .=(isset($instance['button_size']) && $instance['button_size']) ? ' ' . $instance['button_size'] : '';
$button_class   .=(isset($instance['button_margin_top']) && $instance['button_margin_top']) ? ' uk-margin-' . $instance['button_margin_top'].'-top' : ' uk-margin-top';
$button_class   .=(isset($instance['button_shape']) && $instance['button_shape']) ? ' uk-button-' . $instance['button_shape'] : '';

//Slider
$use_slider 	    = (isset($instance['use_slider']) && $instance['use_slider']) ? intval($instance['use_slider']) : 0;
$enable_navigation	= (isset($instance['enable_navigation']) && $instance['enable_navigation']) ? intval($instance['enable_navigation']) : 0;
$enable_dotnav	    = (isset($instance['enable_dotnav']) && $instance['enable_dotnav']) ? intval($instance['enable_dotnav']) : 0;
$center_slider	    = (isset($instance['center_slider']) && $instance['center_slider']) ? intval($instance['center_slider']) : 0;
$navigation_position= (isset($instance['navigation_position']) && $instance['navigation_position']) ? $instance['navigation_position'] : '';

//Filter
$use_filter 	    = (isset($instance['use_filter']) && $instance['use_filter']) ? intval($instance['use_filter']) : 0;
$filter_type 	    = (isset($instance['filter_type']) && $instance['filter_type']) ? $instance['filter_type'] : 'tag';
$filter_position 	= (isset($instance['filter_position']) && $instance['filter_position']) ? $instance['filter_position'] : 'top';
$filter_container	= (isset($instance['filter_container']) && $instance['filter_container']) ? ' uk-container-'. $instance['filter_container'] : '';
$filter_grid_gap	= (isset($instance['filter_grid_gap']) && $instance['filter_grid_gap']) ? ' uk-grid-'. $instance['filter_grid_gap'] : '';
$use_filter_sort 	= (isset($instance['use_filter_sort']) && $instance['use_filter_sort']) ? intval($instance['use_filter_sort']) : 0;
$display_filter_header 	= (isset($instance['display_filter_header']) && $instance['display_filter_header']) ? intval($instance['display_filter_header']) : 0;
$filter_animate 	= (isset($instance['filter_animate']) && $instance['filter_animate']) ? $instance['filter_animate'] : 'slide';
$filter_margin 	    = (isset($instance['filter_margin']) && $instance['filter_margin']) ? ' uk-margin-'. $instance['filter_margin'] : ' uk-margin';
$filter_visibility 	= (isset($instance['filter_visibility']) && $instance['filter_visibility']) ? $instance['filter_visibility'] : '';

$flex_alignment          = ( isset( $instance['filter_text_alignment'] ) && $instance['filter_text_alignment'] ) ? ' uk-flex-' . $instance['filter_text_alignment'] : '';
$flex_breakpoint         = ( $flex_alignment ) ? ( ( isset( $instance['filter_text_alignment_breakpoint'] ) && $instance['filter_text_alignment_breakpoint'] ) ? '@' . $instance['filter_text_alignment_breakpoint'] : '' ) : '';
$flex_alignment_fallback = ( $flex_alignment && $flex_breakpoint ) ? ( ( isset( $instance['filter_text_alignment_fallback'] ) && $instance['filter_text_alignment_fallback'] ) ? ' uk-flex-' . $instance['filter_text_alignment_fallback'] : '' ) : '';
$flex_alignment          .=$flex_breakpoint. $flex_alignment_fallback;

$text_alignment          = ( isset( $instance['filter_text_alignment'] ) && $instance['filter_text_alignment'] ) ? ' uk-text-' . $instance['filter_text_alignment'] : '';
$text_breakpoint         = ( $text_alignment ) ? ( ( isset( $instance['filter_text_alignment_breakpoint'] ) && $instance['filter_text_alignment_breakpoint'] ) ? '@' . $instance['filter_text_alignment_breakpoint'] : '' ) : '';
$text_alignment_fallback = ( $text_alignment && $text_breakpoint ) ? ( ( isset( $instance['filter_text_alignment_fallback'] ) && $instance['filter_text_alignment_fallback'] ) ? ' uk-text-' . $instance['filter_text_alignment_fallback'] : '' ) : '';
$text_alignment          .=$text_breakpoint. $text_alignment_fallback;

$filter_align           =   $flex_alignment.$text_alignment;

$block_align            = ( isset( $instance['filter_block_align'] ) && $instance['filter_block_align'] ) ? $instance['filter_block_align'] : '';
$block_align_breakpoint = ( isset( $instance['filter_block_align_breakpoint'] ) && $instance['filter_block_align_breakpoint'] ) ? '@' . $instance['filter_block_align_breakpoint'] : '';
$block_align_fallback   = ( isset( $instance['filter_block_align_fallback'] ) && $instance['filter_block_align_fallback'] ) ? $instance['filter_block_align_fallback'] : '';

// Block Alignment CLS.
$filter_block_cls[] = '';

if ( empty( $block_align ) ) {
	if ( ! empty( $block_align_breakpoint ) && ! empty( $block_align_fallback ) ) {
		$filter_block_cls[] = ' uk-margin-auto-right' . $block_align_breakpoint;
		$filter_block_cls[] = 'uk-margin-remove-left' . $block_align_breakpoint . ( $block_align_fallback == 'center' ? ' uk-margin-auto' : ' uk-margin-auto-left' );
	}
}

if ( $block_align == 'center' ) {
	$filter_block_cls[] = ' uk-margin-auto' . $block_align_breakpoint;
	if ( ! empty( $block_align_breakpoint ) && ! empty( $block_align_fallback ) ) {
		$filter_block_cls[] = 'uk-margin-auto' . ( $block_align_fallback == 'right' ? '-left' : '' );
	}
}

if ( $block_align == 'right' ) {
	$filter_block_cls[] = ' uk-margin-auto-left' . $block_align_breakpoint;
	if ( ! empty( $block_align_breakpoint ) && ! empty( $block_align_fallback ) ) {
		$filter_block_cls[] = $block_align_fallback == 'center' ? 'uk-margin-remove-right' . $block_align_breakpoint . ' uk-margin-auto' : 'uk-margin-auto-left';
	}
}

$filter_block_cls = implode( ' ', array_filter( $filter_block_cls ) );

$general_styles     =   \Templaza_Elements_Elementor_Helper::get_general_styles($instance);

$output         =   '';

if (count($posts)) {
	$output     .=   '<div class="ui-posts'. $general_styles['container_cls'] .'"' . $general_styles['animation'] . '>';
	$output     .=   '<div class="ui-post-inner' . $color_mode . ( $filter_position != 'top' ? $filter_grid_gap : '' ) . $general_styles['content_cls'] . '"'. ( $use_filter ? ' data-uk-filter="target: .ui-post-items; animation: '.$filter_animate.'"' : '' ) . ( $filter_position != 'top' ? ' data-uk-grid' : '' ) .'>';
	if ($use_filter) {
		$output .=  '<div class="ui-post-filter'. $filter_container. $filter_block_cls . $filter_margin . $filter_align . ($filter_visibility ? ' uk-visible'. $filter_visibility : ''). ($filter_position == 'right' ? ' uk-flex-last' : '') .'">';
		$tag_arg    =   array();
		$cat_arg    =   array();
		if ($ajax_loading) {
			$tags   =   get_terms( array ('taxonomy' => $resource. '_tag') );
			if ($tags) {
				foreach ( $tags as $term ) {
					$tag_arg[$term->slug]	=   $term->name;
				}
			}
			$cat_portfolio = $resource == 'post' ? get_terms( array ('taxonomy' => 'category') ) : get_terms( array ('taxonomy' => $resource.'-category') );
			if ($cat_portfolio && count($cat_portfolio)) {
				foreach ( $cat_portfolio as $term ) {
					$cat_arg[$term->slug]   =   $term->name;
				}
			}
		} else {
			foreach ($posts as $item) {
				$tags = wp_get_post_terms( $item->ID , $resource. '_tag' );
				if ($tags) {
					foreach ( $tags as $term ) {
						$tag_arg[$term->slug]	=   $term->name;
					}
				}
				$cat_portfolio = $resource == 'post' ? wp_get_post_terms( $item->ID , 'category' ) : wp_get_post_terms( $item->ID , $resource.'-category' );
				if ($cat_portfolio && count($cat_portfolio)) {
					foreach ( $cat_portfolio as $term ) {
						$cat_arg[$term->slug]   =   $term->name;
					}
				}
			}
		}

		$tags_content   =   $cats_content   =   '<ul class="'.($filter_position != 'top' ? 'uk-nav uk-nav-default' : 'uk-subnav').$filter_align.'"'.($filter_position == 'top' ? ' data-uk-margin' : '').'>';
		if ($display_filter_header) {
			$tags_content   =   '<h5>'.__('Topic', 'templaza-elements').'</h5>'. $tags_content;
			$cats_content   =   '<h5>'.__('Category', 'templaza-elements').'</h5>'. $cats_content;
		}
		if (count($tag_arg)) {
			$tags_content .=  '<li class="uk-active" data-uk-filter-control><a class="uk-button-text" href="#">'.esc_html__('Show All', 'templaza-elements').'</a></li>';
			foreach ($tag_arg as $tag_key => $tag_name) {
				$tags_content .=  '<li data-uk-filter-control="[data-tag*='.$tag_key.']"><a class="uk-button-text" href="#">'.esc_attr($tag_name).'</a></li>';
			}
		}
		if (count($cat_arg)) {
			$cats_content .=  '<li class="uk-active" data-uk-filter-control><a class="uk-button-text" href="#">'.esc_html__('Show All', 'templaza-elements').'</a></li>';
			foreach ($cat_arg as $cat_key => $cat_name) {
				$cats_content .=  '<li data-uk-filter-control="[data-cat*='.$cat_key.']"><a class="uk-button-text" href="#">'.esc_attr($cat_name).'</a></li>';
			}
		}
		$tags_content   .=   '</ul>';
		$cats_content   .=   '</ul>';

		if ( ( is_array($filter_type) && in_array('tag', $filter_type) ) || (is_string($filter_type) && $filter_type == 'tag') ) {
			$output     .=   $tags_content;
		}
		if ( ( is_array($filter_type) && in_array('category', $filter_type) ) || (is_string($filter_type) && $filter_type == 'category') ) {
			$output     .=   $cats_content;
		}
		if ($use_filter_sort) {
			$output     .=   $display_filter_header ? '<h5>'.__('Sort', 'templaza-elements').'</h5>' : '';
			$output     .=   '<ul class="'.($filter_position != 'top' ? 'uk-nav uk-nav-default' : 'uk-subnav').$filter_align.'">';
			$output     .=   '<li data-uk-filter-control="sort: data-date; order: desc"><a class="uk-button-text" href="#">'.__('Newest', 'templaza-elements').'</a></li>';
			$output     .=   '<li data-uk-filter-control="sort: data-date"><a class="uk-button-text" href="#">'.__('Oldest', 'templaza-elements').'</a></li>';
			$output     .=   '<li data-uk-filter-control="sort: data-hits; order: desc"><a class="uk-button-text" href="#">'.__('Most Popular', 'templaza-elements').'</a></li>';
			$output     .=   '</ul>';
		}
		$output .=  '</div>';
	}
	if ($use_slider) {
		$output .= '<div data-uk-slider="'.($center_slider ? 'center: true' : '').'">';
		$output .= '<div class="uk-position-relative">';
		$output .= '<div class="uk-slider-container">';
	}
	$output     .=  '<div class="'.( $filter_position != 'top' ? 'uk-width-expand'.$filter_visibility : '' ).'">';
	$output     .=  '<div class="ui-post-items uk-child-width-1-'.$large_desktop_columns.'@xl uk-child-width-1-'.$desktop_columns.'@l uk-child-width-1-'.$laptop_columns.'@m uk-child-width-1-'.$tablet_columns.'@s uk-child-width-1-'. $mobile_columns . $column_grid_gap . ($use_slider ? ' uk-slider-items': '') .'" data-uk-grid="'.($masonry ? 'masonry:true;' : '').'">';
	foreach ($posts as $item) {
		include plugin_dir_path(__FILE__).'post_item.php';
	}
	$output     .=  '</div>';
	//end grid

	if ( $ajax_loading ){
		$output .=  '<div class="ui-post-loading uk-text-center uk-margin-large">';
		$output .=  '<div data-uk-spinner class="uk-margin-right"></div>';
		$output .=  '<span class="loading">'.esc_html__('Loading more posts...','templaza-elements').'</span>';
		$output .=  '</div>';
	}
	$output     .=  '</div>';
	if ($use_slider) {
		// End Slider Container
		$output  .= '</div>';
		if ($enable_navigation) {
			// Nav
			$output .= '<div class="'.($navigation_position == 'inside' ? '' : 'uk-hidden@l ').'uk-light"><a class="uk-position-center-left uk-position-small" href="#" data-uk-slidenav-previous data-uk-slider-item="previous"></a><a class="uk-position-center-right uk-position-small" href="#" data-uk-slidenav-next data-uk-slider-item="next"></a></div>';
			$output .= $navigation_position == 'inside' ? '' : '<div class="uk-visible@l"><a class="uk-position-center-left-out uk-position-small" href="#" data-uk-slidenav-previous data-uk-slider-item="previous"></a><a class="uk-position-center-right-out uk-position-small" href="#" data-uk-slidenav-next data-uk-slider-item="next"></a></div>';
		}
		$output  .= '</div>';
		if ($enable_dotnav) {
			// Dot nav
			$output .= '<ul class="uk-slider-nav uk-dotnav uk-flex-center uk-margin"></ul>';
		}
		// End Slider
		$output  .= '</div>';
	}

	$output     .=  '</div>';
	if ($ajax_loading) {
		$output     .=  '<input type="hidden" class="ui-post-paging" value="'.base64_encode(json_encode($query_args)).'" />';
		$output     .=  '<input type="hidden" class="ui-current-page" value="'.(get_query_var( 'paged' ) ? get_query_var('paged') : 1).'" />';
		$output     .=  '<input type="hidden" class="ui-post-settings" value="'.base64_encode(json_encode($instance)).'" />';
	}

	$output     .=  '</div>';

	echo ent2ncr($output);
}