<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIImage' ) ) {
	/**
	 * Class Templaza_Elements_Config_UIImage
	 */
	class Templaza_Elements_Config_UIImage extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uiimage';
			self::$name = esc_html__( 'TemPlaza: UI Image', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Image Box.', 'templaza-elements' );
			self::$icon = 'eicon-image';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			// options
			$options = array(
				//Image Settings
				array(
					'type'          =>  Controls_Manager::MEDIA,
					'id'          => 'image',
					'label'         => esc_html__('Select Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Image_Size::get_type(),
					'name' => 'image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [],
					'include' => [],
					'default' => 'large',
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'caption',
					'label'         => esc_html__( 'Caption', 'templaza-elements' ),
					'default'       => __('Your Caption Text Here', 'templaza-elements'),
					'description'   => esc_html__( 'Write the caption for the image.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'image_border',
					'label'         => esc_html__( 'Border', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s border style.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-border-circle' => __('Circle', 'templaza-elements'),
						'uk-border-rounded' => __('Rounded', 'templaza-elements'),
						'uk-border-pill' => __('Pill', 'templaza-elements'),
					),
					'separator'     => 'before',
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'box_shadow',
					'label'         => esc_html__( 'Box Shadow', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s box shadow size.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-box-shadow-small' => __('Small', 'templaza-elements'),
						'uk-box-shadow-medium' => __('Medium', 'templaza-elements'),
						'uk-box-shadow-large' => __('Large', 'templaza-elements'),
						'uk-box-shadow-xlarge' => __('X-Large', 'templaza-elements'),
					),
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'hover_box_shadow',
					'label'         => esc_html__( 'Hover Box Shadow', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s box shadow size on hover.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-box-shadow-hover-small' => __('Small', 'templaza-elements'),
						'uk-box-shadow-hover-medium' => __('Medium', 'templaza-elements'),
						'uk-box-shadow-hover-large' => __('Large', 'templaza-elements'),
						'uk-box-shadow-hover-xlarge' => __('X-Large', 'templaza-elements'),
					),
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'image_panel',
					'label'         => esc_html__('Blend Mode Settings', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'separator'     => 'before',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'id'            => 'blend_bg_color',
					'label'         => esc_html__('Background Color', 'templaza-elements'),
					'description'   => esc_html__('Use the background color in combination with blend modes.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-blend' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
							['name' => 'image_panel', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'image_blend_modes',
					'label'         => esc_html__( 'Blend modes', 'templaza-elements' ),
					'description'   => esc_html__( 'Determine how the image will blend with the background color.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-blend-multiply' => __('Multiply', 'templaza-elements'),
						'uk-blend-screen' => __('Screen', 'templaza-elements'),
						'uk-blend-overlay' => __('Overlay', 'templaza-elements'),
						'uk-blend-darken' => __('Darken', 'templaza-elements'),
						'uk-blend-lighten' => __('Lighten', 'templaza-elements'),
						'uk-blend-color-dodge' => __('Color Dodge', 'templaza-elements'),
						'uk-blend-color-burn' => __('Color Burn', 'templaza-elements'),
						'uk-blend-hard-light' => __('Hard Light', 'templaza-elements'),
						'uk-blend-soft-light' => __('Soft Light', 'templaza-elements'),
						'uk-blend-difference' => __('Difference', 'templaza-elements'),
						'uk-blend-exclusion' => __('Exclusion', 'templaza-elements'),
						'uk-blend-hue' => __('Hue', 'templaza-elements'),
						'uk-blend-color' => __('Color', 'templaza-elements'),
						'uk-blend-luminosity' => __('Luminosity', 'templaza-elements'),
					),
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
							['name' => 'image_panel', 'operator' => '===', 'value' => '1'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'image_transition',
					'label'         => esc_html__( 'Transition', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s transition style.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'scale-up' => __('Scales Up', 'templaza-elements'),
						'scale-down' => __('Scales Down', 'templaza-elements'),
					),
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'link_type',
					'label'         => esc_html__( 'Link Type', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'use_link' => __('Link', 'templaza-elements'),
						'use_modal' => __('Modal', 'templaza-elements'),
					),
					'separator'     => 'before',
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::URL,
					'id'            => 'link',
					'label'         => __( 'Image Url', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					'default'       => [
						'url'       => '',
					],
					'conditions' => [
						'terms' => [
							['name' => 'image[url]', 'operator' => '!==', 'value' => ''],
							['name' => 'link_type', 'operator' => '!==', 'value' => ''],
						],
					],
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}