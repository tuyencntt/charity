<?php
/**
 * Templaza_Elements Ui Icon config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_Templaza_Testimonial' ) ) {
	/**
	 * Class Templaza_Elements_Config_Templaza_Testimonial
	 */
	class Templaza_Elements_Config_Templaza_Testimonial extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Templaza_Testimonial constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'templaza-testimonial';
			self::$name = esc_html__( 'TemPlaza: Testimonial', 'templaza-elements' );
			self::$desc = esc_html__( 'Display Testimonial.', 'templaza-elements' );
			self::$icon = 'eicon-blockquote';
			parent::__construct();
		}

		/**
		 * @return array
		 */
		public function get_options() {
            $repeater = new \Elementor\Repeater();
            $repeater->add_control(
                'quote_content', [
                    'label' => __( 'Content quote', 'plugin-domain' ),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => __( '' , 'plugin-domain' ),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'quote_author', [
                    'label' => __( 'Author', 'plugin-domain' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '' , 'plugin-domain' ),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'author_position', [
                    'label' => __( 'Author Position', 'plugin-domain' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( '' , 'plugin-domain' ),
                    'label_block' => true,
                ]
            );
			$repeater->add_control(
				'author_image',
				[
					'type'          =>  Controls_Manager::MEDIA,
					'id'          => 'image',
					'label'         => esc_html__('Select Avatar Image:', 'templaza-elements'),
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Image_Size::get_type(),
				[
					'name' => 'author_image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [ 'custom' ],
					'include' => [],
					'default' => 'full',
				]
			);
			// options
			$options = array(
				array(
					'type'      => Controls_Manager::REPEATER,
                    'name'      => 'templaza-testimonial',
					'label'     => esc_html__( 'Testimonial', 'templaza-elements' ),
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'quote_content' => ''
                        ],
                    ],
                    'title_field' => __( 'Quote item', 'plugin-domain' ),
				),
                array(
                    'type'      => Controls_Manager::SWITCHER,
                    'name'      => 'testimonial_slider_autoplay',
                    'label'     => esc_html__( 'Autoplay', 'templaza-elements' ),
                    'start_section' => 'slider-options',
                    'section_name'  => esc_html__( 'Slider options', 'templaza-elements' ),
                ),
                array(
                    'type'      => Controls_Manager::SWITCHER,
                    'name'      => 'testimonial_slider_center',
                    'label'     => esc_html__( 'Center', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Slider options', 'templaza-elements' ),
                ),
                array(
                    'type'      => Controls_Manager::SWITCHER,
                    'name'      => 'testimonial_slider_navigation',
                    'label'     => esc_html__( 'Navigation', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Slider options', 'templaza-elements' ),
                ),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'testimonial_slider_navigation_position',
					'label'         => esc_html__( 'Navigation Position', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s position.', 'templaza-elements' ),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'uk-position-top-left' => __('Top Left', 'templaza-elements'),
						'uk-position-top-right' => __('Top Right', 'templaza-elements'),
						'uk-position-bottom-left' => __('Bottom Left', 'templaza-elements'),
						'uk-position-bottom-right' => __('Bottom Right', 'templaza-elements'),
					),
					'default'       => '',
					'conditions' => [
						'terms' => [
							['name' => 'testimonial_slider_navigation', 'operator' => '===', 'value' => 'yes'],
						],
					],
				),
                array(
                    'type'      => Controls_Manager::SWITCHER,
                    'name'      => 'testimonial_slider_navigation_outside',
                    'label'     => esc_html__( 'Navigation outside', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Slider options', 'templaza-elements' ),
                    'conditions' => [
	                    'terms' => [
		                    ['name' => 'testimonial_slider_navigation', 'operator' => '===', 'value' => 'yes'],
		                    ['name' => 'testimonial_slider_navigation_position', 'operator' => '===', 'value' => ''],
	                    ],
                    ],
                ),

                array(
                    'type'      => Controls_Manager::SWITCHER,
                    'name'      => 'testimonial_slider_dot',
                    'label'     => esc_html__( 'Show dots', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Slider options', 'templaza-elements' ),
                ),
                array(
                    'type'      => Controls_Manager::NUMBER,
                    'name'      => 'testimonial_slider_number',
                    'label'     => esc_html__( 'Number item', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Slider options', 'templaza-elements' ),
                ),
				array(
					'name'          => 'testimonial_quote_size',
					'label' => __( 'Quote Size', 'templaza-elements' ),
					'description'   => esc_html__('Size of quote icon', 'templaza-elements'),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 5,
							'max' => 300,
							'step' => 1,
						],
					],
					'default' => [
						'size' => 50,
					],
					'start_section' => 'style',
					'section_tab'   => Controls_Manager::TAB_STYLE,
					'section_name'  => esc_html__( self::$name, 'templaza-elements' ),
				),
				array(
					'id'            => 'avatar_size',
					'label'         => __( 'Avatar Size', 'templaza-elements' ),
					'type'          => Controls_Manager::SLIDER,
					'size_units'    => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ui-testimonial-avatar img' => 'width: {{SIZE}}{{UNIT}};',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'avatar_border',
					'label'         => esc_html__( 'Avatar Border', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s border style.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-border-circle' => __('Circle', 'templaza-elements'),
						'uk-border-rounded' => __('Rounded', 'templaza-elements'),
						'uk-border-pill' => __('Pill', 'templaza-elements'),
					),
					'default'       => '',
				),
                array(
                    'type'          => Group_Control_Typography::get_type(),
                    'name'          => 'quote_content_typography',
                    'scheme'        => Typography::TYPOGRAPHY_1,
                    'label'         => esc_html__('Content Font', 'templaza-elements'),
                    'selector'      => '{{WRAPPER}} .templaza_quote_content',
                    'start_section' => 'style',
                    'section_tab'   => Controls_Manager::TAB_STYLE,
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),

                ),
                array(
                    'type'          => Group_Control_Typography::get_type(),
                    'name'          => 'quote_author_typography',
                    'scheme'        => Typography::TYPOGRAPHY_1,
                    'label'         => esc_html__('Author Font', 'templaza-elements'),
                    'selector'      => '{{WRAPPER}} .templaza_quote_author',
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),

                ),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'quote_designation_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Designation Font', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .templaza_quote_author_position',
					'section_name'  => esc_html__( self::$name, 'templaza-elements' ),

				),
			);
			return array_merge($options, $this->get_general_options());
		}

        public function get_template_name() {
            return 'base';
        }
	}
}