<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIPerson' ) ) {
	/**
	 * Class Templaza_Elements_Config_UIPerson
	 */
	class Templaza_Elements_Config_UIPerson extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uiperson';
			self::$name = esc_html__( 'TemPlaza: UI Person', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Person Box.', 'templaza-elements' );
			self::$icon = 'eicon-person';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'social_icon',
				[
					'type'          => Controls_Manager::SELECT,
					'label'         => esc_html__('Social Icon', 'templaza-elements'),
					'description'   => esc_html__('Select a social icon', 'templaza-elements'),
					'options'       => array(
						'' => __( 'Select an Icon', 'templaza-elements' ),
						'500px' => __( '500px', 'templaza-elements' ),
						'behance' => __( 'Behance', 'templaza-elements' ),
						'dribbble' => __( 'Dribbble', 'templaza-elements' ),
						'facebook' => __( 'Facebook', 'templaza-elements' ),
						'flickr' => __( 'Flickr', 'templaza-elements' ),
						'foursquare' => __( 'Foursquare', 'templaza-elements' ),
						'github' => __( 'Github', 'templaza-elements' ),
						'github-alt' => __( 'Github-alt', 'templaza-elements' ),
						'gitter' => __( 'Gitter', 'templaza-elements' ),
						'google' => __( 'Google', 'templaza-elements' ),
						'google-plus' => __( 'Google-plus', 'templaza-elements' ),
						'instagram' => __( 'Instagram', 'templaza-elements' ),
						'joomla' => __( 'Joomla', 'templaza-elements' ),
						'linkedin' => __( 'Linkedin', 'templaza-elements' ),
						'pinterest' => __( 'Pinterest', 'templaza-elements' ),
						'soundcloud' => __( 'Soundcloud', 'templaza-elements' ),
						'tripadvisor' => __( 'Tripadvisor', 'templaza-elements' ),
						'tumblr' => __( 'Tumblr', 'templaza-elements' ),
						'twitter' => __( 'Twitter', 'templaza-elements' ),
						'twitch' => __( 'Twitch', 'templaza-elements' ),
						'discord' => __( 'Discord', 'templaza-elements' ),
						'etsy' => __( 'Etsy', 'templaza-elements' ),
						'tiktok' => __( 'Tiktok', 'templaza-elements' ),
						'vimeo' => __( 'Vimeo', 'templaza-elements' ),
						'whatsapp' => __( 'Whatsapp', 'templaza-elements' ),
						'wordpress' => __( 'Wordpress', 'templaza-elements' ),
						'xing' => __( 'Xing', 'templaza-elements' ),
						'yelp' => __( 'Yelp', 'templaza-elements' ),
						'youtube' => __( 'Youtube', 'templaza-elements' ),
						'reddit' => __( 'Reddit', 'templaza-elements' ),
					),
					'default'           => '',
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'templaza-elements' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);
			// options
			$options = array(
				array(
					'type'          =>  Controls_Manager::MEDIA,
					'name'          => 'image',
					'label'         => esc_html__('Select Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Image_Size::get_type(),
					'name' => 'image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [],
					'include' => [],
					'default' => 'large',
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'name'          => 'name',
					'label'         => esc_html__( 'Name', 'templaza-elements' ),
					'default'       => __('Alex Raykowitz', 'templaza-elements'),
					'description'   => esc_html__( 'Write the Name for the person.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'name'          => 'designation',
					'label'         => esc_html__( 'Designation', 'templaza-elements' ),
					'placeholder'       => __('Your Designation Here', 'templaza-elements'),
					'description'   => esc_html__( 'Write the title for the designation.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'name'          => 'email',
					'label'         => esc_html__( 'Email', 'templaza-elements' ),
					'placeholder'       => __('Your Email Here', 'templaza-elements'),
					'description'   => esc_html__( 'Write the address for the email.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				//Content Settings
				array(
					'name'          => 'text',
					'label'         => esc_html__('Content', 'templaza-elements'),
					'type' => Controls_Manager::WYSIWYG,
					'default' => __( 'Animal mnesarchum et sea, ad sale luptatum mea.', 'templaza-elements' ),
					'placeholder' => __( 'Type your description here', 'templaza-elements' ),
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'text_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-card .ui-card-text',
					'condition'     => array(
						'text!'    => ''
					),
				),
				array(
					'type'      => Controls_Manager::REPEATER,
					'id'      => 'social_items',
					'label'     => esc_html__( 'Social Items', 'templaza-elements' ),
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'link' => 'Social Item',
						],
					],
					'title_field' => __( 'Social Item', 'templaza-elements' ),
				),

				//Card Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_style',
					'label' => __( 'Card Style', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('None', 'templaza-elements'),
						'default' => __('Card Default', 'templaza-elements'),
						'primary' => __('Card Primary', 'templaza-elements'),
						'secondary' => __('Card Secondary', 'templaza-elements'),
						'hover' => __('Card Hover', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
					'start_section' => 'card',
					'section_name'      => esc_html__('Card Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background',
					'label'         => esc_html__('Card Background', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-card' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color',
					'label'         => esc_html__('Card Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-card' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_size',
					'label' => __( 'Card Size', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					],
				),

				//Image Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'image_appear',
					'label' => __( 'Image Appear', 'templaza-elements' ),
					'default' => 'top',
					'options' => [
						'top'        => __( 'Top', 'templaza-elements' ),
						'inside'   => __( 'Inside', 'templaza-elements' ),
						'bottom'   => __( 'Bottom', 'templaza-elements' ),
					],
					'start_section' => 'image_settings',
					'section_name'      => esc_html__('Image Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'media_margin',
					'label'         => esc_html__('Media Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for Image.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Name settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'name_tag',
					'label'         => esc_html__( 'Name tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
					),
					'default'       => 'h3',
					'description'   => esc_html__( 'Choose heading element.', 'templaza-elements' ),
					/* vc */
					'admin_label' => false,
					'start_section' => 'name_settings',
					'section_name'      => esc_html__('Name Settings', 'templaza-elements')
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'name_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Name Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon name.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-name',
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'name_color',
					'label'         => esc_html__('Title Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of name.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-name' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'name_heading_style',
					'default'       => 'h3',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Heading styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'name_position',
					'label'         => esc_html__('Icon/Image Position', 'templaza-elements'),
					'description'   => esc_html__('Set the icon/image position.', 'templaza-elements'),
					'options'       => array(
						'after'     => esc_html__('Before Title', 'templaza-elements'),
						'before'    => esc_html__('After Title', 'templaza-elements'),
					),
					'default'       => 'after',
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'name_heading_margin',
					'label'         => esc_html__('Title Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for name.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Designation settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'designation_tag',
					'label'         => esc_html__( 'Designation tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
						'lead'      => 'lead',
						'meta'      => 'meta'
					),
					'default'       => 'meta',
					'description'   => esc_html__( 'Choose Designation element.', 'templaza-elements' ),
					/* vc */
					'admin_label' => false,
					'start_section' => 'designation_settings',
					'section_name'      => esc_html__('Designation Settings', 'templaza-elements')
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'designation_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Designation Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-designation',
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'designation_color',
					'label'         => esc_html__('Designation Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of designation.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-designation' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'designation_margin',
					'label'         => esc_html__('Designation Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for designation.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Email settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'email_tag',
					'label'         => esc_html__( 'Email tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
						'lead'      => 'lead',
						'meta'      => 'meta'
					),
					'default'       => 'meta',
					'description'   => esc_html__( 'Choose Email element.', 'templaza-elements' ),
					/* vc */
					'admin_label' => false,
					'start_section' => 'email_settings',
					'section_name'      => esc_html__('Email Settings', 'templaza-elements')
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'email_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Email Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-email',
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'email_color',
					'label'         => esc_html__('Email Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of email.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-email' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'email_margin',
					'label'         => esc_html__('Email Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for email.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Social Settings
				array(
					'id'          => 'overlay_positions',
					'label' => __( 'Overlay Positions', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'center',
					'options' => array(
						'top' => __( 'Top', 'templaza-elements' ),
						'bottom' => __( 'Bottom', 'templaza-elements' ),
						'left' => __( 'Left', 'templaza-elements' ),
						'right' => __( 'Right', 'templaza-elements' ),
						'top-left' => __( 'Top Left', 'templaza-elements' ),
						'top-center' => __( 'Top Center', 'templaza-elements' ),
						'top-right' => __( 'Top Right', 'templaza-elements' ),
						'bottom-left' => __( 'Bottom Left', 'templaza-elements' ),
						'bottom-center' => __( 'Bottom Center', 'templaza-elements' ),
						'bottom-right' => __( 'Bottom Right', 'templaza-elements' ),
						'center' => __( 'Center', 'templaza-elements' ),
						'center-left' => __( 'Center Left', 'templaza-elements' ),
						'center-right' => __( 'Center Right', 'templaza-elements' ),
					),
					'start_section' => 'social_settings',
					'section_name'      => esc_html__('Social Settings', 'templaza-elements')
				),
				array(
					'id'    =>  'overlay_alignment',
					'type' => \Elementor\Controls_Manager::SELECT,
					'label' => __( 'Alignment', 'templaza-elements' ),
					'options' => array(
						'' => __( 'None', 'templaza-elements' ),
						'left' => __( 'Left', 'templaza-elements' ),
						'center' => __( 'Center', 'templaza-elements' ),
						'right' => __( 'Right', 'templaza-elements' ),
					),
					'default' => 'center',
				),
				array(
					'id'            => 'vertical_icons',
					'type'          => Controls_Manager::SWITCHER,
					'label' => __('Vertical Social Icons', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}