<?php
/**
 * Templaza_Elements Visual Composer List Post shortcode
 *
 * @version     1.0.0
 * @author      ThimPress
 * @package     Templaza_Elements/Classes
 * @category    Classes
 * @author      Thimpress, tuanta
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Templaza_Elements_VC_List_Post' ) ) {
	/**
	 * Class Templaza_Elements_VC_List_Post
	 */
	class Templaza_Elements_VC_List_Post extends Templaza_Elements_VC_Shortcode {

		/**
		 * Templaza_Elements_VC_List_Post constructor.
		 */
		public function __construct() {
			// set config class
			$this->config_class = 'Templaza_Elements_Config_List_Post';

			parent::__construct();
		}
	}
}

new Templaza_Elements_VC_List_Post();