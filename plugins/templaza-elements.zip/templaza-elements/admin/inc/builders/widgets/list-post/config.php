<?php
/**
 * Templaza_Elements List Post config class
 *
 * @version     1.0.0
 * @author      ThimPress
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;

if ( ! class_exists( 'Templaza_Elements_Config_List_Post' ) ) {
	/**
	 * Class Templaza_Elements_Config_Accordion
	 */
	class Templaza_Elements_Config_List_Post extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_List_Post constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'list-post';
			self::$name = esc_html__( 'TemPlaza: List Posts', 'templaza-elements' );
			self::$desc = esc_html__( 'Display list posts.', 'templaza-elements' );
			self::$icon = 'eicon-post-list';
			parent::__construct();
		}

		/**
		 * @return array
		 */
		public function get_options() {

//		    var_dump(Templaza_Elements_Builders_Helper::get_cat_taxonomy( 'category',
//                array( esc_html__( 'All', 'templaza-elements' ) => 'all' ))); die();
		    // Options
            return array(
                array(
                    'type'          => Controls_Manager::TEXT,
                    'name'          => 'title',
                    'show_label'    => true,
                    'label'         => esc_html__( 'Title', 'templaza-elements' ),
                    'default'       => '',
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'            => 'cat_id',
                    'label'         => esc_html__( 'Select Category', 'templaza-elements' ),
                    'options'       => Templaza_Elements_Builders_Helper::get_cat_taxonomy( 'category',
                        array( 'all'  => esc_html__( 'All', 'templaza-elements' )) ),
                    'default'       => 'all'
                ),
                array(
                    'type'          => Controls_Manager::NUMBER,
                    'name'          => 'number_posts',
                    'show_label'    => true,
                    'label'         => esc_html__( 'Number posts', 'templaza-elements' ),
                    'default'       => '4',
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'orderby',
                    'show_label'    => true,
                    'label'         => esc_html__( 'Order by', 'templaza-elements' ),
                    'options'       => array(
                        ''          => esc_html__( 'Select', 'templaza-elements' ),
                        'popular'   => esc_html__( 'Popular', 'templaza-elements' ),
                        'recent'    => esc_html__( 'Recent', 'templaza-elements' ),
                        'title'     => esc_html__( 'Title', 'templaza-elements' ),
                        'random'    => esc_html__( 'Random', 'templaza-elements' ),
                    ),
                    'default'       => 'popular'
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'order',
                    'show_label'    => true,
                    'label'         => esc_html__( 'Order', 'templaza-elements' ),
                    'options'       => array(
                        ''      => esc_html__( 'Select', 'templaza-elements' ),
                        'asc'   => esc_html__( 'ASC', 'templaza-elements' ),
                        'desc'  => esc_html__( 'DESC', 'templaza-elements' ),
                    ),
                    'default'         => 'asc'
                ),
                array(
                    'type'      => Controls_Manager::SELECT,
                    'name'      => 'post_size',
                    'label'     => __( 'Post Title Tag', 'templaza-elements' ),
                    'options'   => [
                        'h1' => 'H1',
                        'h2' => 'H2',
                        'h3' => 'H3',
                        'h4' => 'H4',
                        'h5' => 'H5',
                        'h6' => 'H6',
                        'div' => 'div',
                        'span' => 'span',
                        'p' => 'p',
                    ],
                    'default'   => 'h3',
                ),
                array(
                    'type'          => Controls_Manager::SELECT2,
                    'name'          => 'post_heading_style',
                    'default'       => '',
                    'label'         => esc_html__('Post Title Style', 'templaza-elements'),
                    'description'   => esc_html__('Heading styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
                    'options'       => array(
                        ''                  => esc_html__('None', 'templaza-elements'),
                        'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
                        'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
                        'heading-large'     => esc_html__('Large', 'templaza-elements'),
                        'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
                        'heading-small'     => esc_html__('Small', 'templaza-elements'),
                        'h1'                => esc_html__('H1', 'templaza-elements'),
                        'h2'                => esc_html__('H2', 'templaza-elements'),
                        'h3'                => esc_html__('H3', 'templaza-elements'),
                        'h4'                => esc_html__('H4', 'templaza-elements'),
                        'h5'                => esc_html__('H5', 'templaza-elements'),
                        'h6'                => esc_html__('H6', 'templaza-elements'),
                    ),
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'layout',
                    'show_label'    => true,
                    'label'         => esc_html__( 'Layout', 'templaza-elements' ),
                    'options'       => array(
                        'base'  => esc_html__( 'Default', 'templaza-elements' ),
                        'grid'  => esc_html__( 'Grid', 'templaza-elements' ),
                    ),
                    'default'       => 'base',
                ),
                array(
                    'type'          => Controls_Manager::SWITCHER,
                    'name'          => 'show_date',
                    'label'         => esc_html__( 'Show Date', 'templaza-elements' ),
                    'default'       => 'yes',
                    'separator'     => 'before',
                    /* vc params */
                    'value'         => array(
                        esc_html__( 'Yes', 'templaza-elements' ) => true,
                    ),
                    'save_always'   => true,
                ),
                array(
                    'type'          => Controls_Manager::SWITCHER,
                    'name'          => 'show_author',
                    'label'         => esc_html__( 'Show Author', 'templaza-elements' ),
                    'default'       => 'yes',
                    /* vc params */
                    'value'         => array(
                        esc_html__( 'Yes', 'templaza-elements' ) => true,
                    ),
                    'save_always'   => true,
                ),
                array(
                    'type'          => Controls_Manager::SWITCHER,
                    'name'          => 'show_category',
                    'label'         => esc_html__( 'Show Category', 'templaza-elements' ),
                    'default'       => 'yes',
                    /* vc params */
                    'value'         => array(
                        esc_html__( 'Yes', 'templaza-elements' ) => true,
                    ),
                    'save_always'   => true,
                ),
                array(
                    'type'          => Controls_Manager::SWITCHER,
                    'name'          => 'show_post_count',
                    'label'         => esc_html__( 'Show Post Count', 'templaza-elements' ),
                    'default'       => 'yes',
                    'condition'     => array(
                        'layout'    => 'base'
                    ),
                    /* vc params */
                    'value'         => array(
                        esc_html__( 'Yes', 'templaza-elements' ) => true,
                    ),
                    'save_always'   => true,
                ),
                array(
                    'type'          => Controls_Manager::SWITCHER,
                    'name'          => 'show_description',
                    'label'         => esc_html__( 'Show Description', 'templaza-elements' ),
                    'default'       => 'yes',
                    /* vc params */
                    'value'         => array(
                        esc_html__( 'Yes', 'templaza-elements' ) => true,
                    ),
                    'save_always'   => true,
                ),
                array(
                    'type'          => Controls_Manager::NUMBER,
                    'name'          => 'description_limit',
                    'label'         => esc_html__('Description Limit', 'templaza-elements'),
                    'min'           => 0,
                    'default'       => 13,
                    'condition'     => ['show_description' => 'yes'],
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'image_size',
                    'label'         => esc_html__( 'Select Image Size', 'templaza-elements' ),
                    'options'       => Templaza_Elements_Builders_Helper::get_list_image_size(),
                    'default'       => 'none',
                    'condition'     => ['layout' => 'base'],
                ),
                array(
                    'type'          => Controls_Manager::ICONS,
                    'name'          => 'list_icon',
                    'label'         => esc_html__( 'Post List Icon', 'templaza-elements' ),
                    /* vc params */
                    'value'         => '',
                    'admin_label'   => true,
                ),

                /* Grid settings */
                array(
                    'type'          => Controls_Manager::SWITCHER,
                    'name'          => 'item_horizontal',
                    'label'         => esc_html__( 'Horizontal Alignment', 'templaza-elements' ),
                    'condition'     => array(
                        'layout'    => 'grid',
                    ),
                    'start_section'     => 'grid_settings',
                    'section_name'      => esc_html__( 'Grid Settings', 'templaza-elements' ),
                    /* vc param */
                    'value'         => '',
                    'admin_label'   => true,
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'img_h_align',
                    'label'         => esc_html__( 'Image Align', 'templaza-elements' ),
                    'options'       => [
                        'left'      => __( 'Left', 'templaza-elements' ),
                        'right'     => __( 'Right', 'templaza-elements' ),
                    ],
                    'default'       => 'left',
                    'condition'     => array(
                        'layout'            => 'grid',
                        'item_horizontal'   => 'yes',
                    ),
                    'section_name'      => esc_html__( 'Grid Settings', 'templaza-elements' ),
                    /* vc param */
                    'value'         => '',
                    'admin_label'   => true,
                ),
                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'img_align',
                    'label'         => esc_html__( 'Image Align', 'templaza-elements' ),
                    'options'       => [
                        'top'       => __( 'Top', 'templaza-elements' ),
                        'bottom'    => __( 'Bottom', 'templaza-elements' ),
                    ],
                    'default'       => 'top',
                    'condition'     => array(
                        'layout'            => 'grid',
                        'item_horizontal!'  => 'yes',
                    ),
                    'section_name'      => esc_html__( 'Grid Settings', 'templaza-elements' ),
                    /* vc param */
                    'value'         => '',
                    'admin_label'   => true,
                ),

                array(
                    'type'          => Controls_Manager::SELECT,
                    'name'          => 'column',
                    'label'         => esc_html__( 'Columns', 'templaza-elements' ),
                    'options'       => array(
                        1     => esc_html__( '1', 'templaza-elements' ),
                        2     => esc_html__( '2', 'templaza-elements' ),
                        3     => esc_html__( '3', 'templaza-elements' ),
                        4     => esc_html__( '4', 'templaza-elements' ),
                        5     => esc_html__( '5', 'templaza-elements' ),
                        6     => esc_html__( '6', 'templaza-elements' ),
                    ),
                    'desktop_default'       => 3,
                    'tablet_default'        => 2,
                    'mobile_default'        => 1,
                    'responsive'            => true,
                    'condition'             => array(
                        'layout'            => 'grid',
                        'item_horizontal!'  => 'yes',
                    ),
                    'section_name'          => esc_html__( 'Grid Settings', 'templaza-elements' ),
                    /* vc param */
                    'admin_label'           => true,
                ),
                array(
                    'type'          => Controls_Manager::TEXT,
                    'name'          => 'img_w',
                    'show_label'    => true,
                    'label'         => esc_html__( 'Image width', 'templaza-elements' ),
                    'condition'     => array(
                        'layout'    => 'grid',
                    ),
                    'section_name'  => esc_html__( 'Grid Settings', 'templaza-elements' ),
//                    /* vc param */
//                    'group'         => esc_html__( 'Grid Settings', 'templaza-elements' ),
                ),

                array(
                    'type'          => Controls_Manager::TEXT,
                    'name'          => 'img_h',
                    'label'         => esc_html__( 'Image height', 'templaza-elements' ),
                    'condition'     => array(
                        'layout'    => 'grid',
                    ),
                    'section_name'  => esc_html__( 'Grid Settings', 'templaza-elements' ),
                    /* vc param */
                    'value'         => '',
                    'admin_label'   => true,
                ),

//                array(
//                    'type'          => Controls_Manager::SWITCHER,
//                    'name'          => 'display_feature',
//                    'label'         => esc_html__( 'Show feature posts', 'templaza-elements' ),
//                    'condition'     => array(
//                        'layout'    => 'grid',
//                    ),
//                    'start_section' => 'grid_settings',
//                    'section_name'  => esc_html__( 'Grid Settings', 'templaza-elements' ),
//                    /* vc params */
//                    'value'         => array(
//                        esc_html__( 'Yes', 'templaza-elements' ) => 'yes',
//                    ),
////                    'group'         => esc_html__( 'Grid Settings', 'templaza-elements' ),
//                ),

//                array(
//                    'type'          => Controls_Manager::NUMBER,
//                    'name'          => 'item_vertical',
//                    'show_label'    => true,
//                    'label'         => esc_html__( 'Items vertical', 'templaza-elements' ),
//                    'default'       => '0',
//                    'condition'     => array(
//                        'layout'    => 'grid',
//                    ),
//                    'start_section' => 'grid_settings',
//                    'section_name'  => esc_html__( 'Grid Settings', 'templaza-elements' ),
//                    /* vc params */
////                    'group'         => esc_html__( 'Grid Settings', 'templaza-elements' ),
//                ),

                /* Start Link */
                array(
                    'type'          => Controls_Manager::TEXT,
                    'name'          => 'link',
                    'label'         => esc_html__( 'Link All Posts', 'templaza-elements' ),
                    'start_section' => 'tz_link',
                    'section_name'  => esc_html__( 'Link', 'templaza-elements' ),
                    /* vc params */
                    'value'         => '',
                    'admin_label'   => true,
                ),

                array(
                    'type'          => Controls_Manager::TEXT,
                    'name'          => 'text_link',
                    'label'         => esc_html__( 'Text All Posts', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Link', 'templaza-elements' ),
                    /* vc params */
                    'value'         => '',
                    'admin_label'   => true,
                ),

                array(
                    'type'          => Controls_Manager::ICONS,
                    'name'          => 'link_icon',
                    'label'         => esc_html__( 'Link All Icon', 'templaza-elements' ),
                    'section_name'  => esc_html__( 'Link', 'templaza-elements' ),
                    /* vc params */
                    'value'         => '',
                    'admin_label'   => true,
                ),

                /* Style tab */
                array(
                    'type'          => Group_Control_Typography::get_type(),
                    'name'          => 'typography',
                    'label'         => esc_html__('Typography'),
                    'scheme'        => Typography::TYPOGRAPHY_1,
                    'start_section' => 'style',
                    'section_tab'   => Controls_Manager::TAB_STYLE,
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),
                    'selector'      => '{{WRAPPER}}',
                ),
                array(
                    'type'          => Group_Control_Typography::get_type(),
                    'name'          => 'meta_typography',
                    'label'         => esc_html__('Post Count Typography'),
                    'scheme'        => Typography::TYPOGRAPHY_1,
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),
                    'selector'      => '{{WRAPPER}} .number-posts',
                ),
                array(
                    'type'          => Group_Control_Typography::get_type(),
                    'name'          => 'post_title_typography',
                    'label'         => esc_html__('Post Title Typography'),
                    'scheme'        => Typography::TYPOGRAPHY_1,
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),
                    'selector'      => '{{WRAPPER}} .article-heading',
                ),
                array(
                    'type'          => Group_Control_Typography::get_type(),
                    'name'          => 'link_all_typography',
                    'label'         => esc_html__('Link All Typography'),
                    'scheme'        => Typography::TYPOGRAPHY_1,
                    'section_name'  => esc_html__( self::$name, 'templaza-elements' ),
                    'selector'      => '{{WRAPPER}} .read-more',
                ),
            );
		}

	}
}