<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIPricing' ) ) {
	/**
	 * Class Templaza_Elements_Config_UIPricing
	 */
	class Templaza_Elements_Config_UIPricing extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uipricing';
			self::$name = esc_html__( 'TemPlaza: UI Pricing', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Pricing Box.', 'templaza-elements' );
			self::$icon = 'eicon-price-table';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'text',
				[
					'type'          => Controls_Manager::TEXT,
					'label'         => esc_html__( 'Item', 'templaza-elements' ),
					'description'   => esc_html__( 'Write the title for the item.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'templaza-elements' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);
			$repeater->add_control(
				'icon_type',
				[
					'type'          => Controls_Manager::SELECT,
					'label' => __( 'Icon Type', 'templaza-elements' ),
					'default' => '',
					'options' => [
						''  => __( 'FontAwesome', 'templaza-elements' ),
						'uikit' => __( 'UIKit', 'templaza-elements' ),
					],
				]
			);
			$repeater->add_control(
				'icon',
				[
					'type'          => Controls_Manager::ICONS,
					'label'         => esc_html__('Select Icon:', 'templaza-elements'),
					'conditions' => [
						'terms' => [
							['name' => 'icon_type', 'operator' => '===', 'value' => ''],
						],
					],
				]
			);
			$repeater->add_control(
				'uikit_icon',
				[
					'type'          => Controls_Manager::SELECT2,
					'label'         => esc_html__('Select Icon:', 'templaza-elements'),
					'default' => '',
					'conditions' => [
						'terms' => [
							['name' => 'icon_type', 'operator' => '===', 'value' => 'uikit'],
						],
					],
					'options' => $this->get_font_uikit(),
				]
			);
			$repeater->add_control(
				'icon_color',
				[
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Icon Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of Icon.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-icon{{CURRENT_ITEM}}' => 'color: {{VALUE}}',
					],
				]
			);

			// options
			$options = array(
				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'title',
					'label'         => esc_html__( 'Title', 'templaza-elements' ),
					'default'       => __('Small Business', 'templaza-elements'),
					'description'   => esc_html__( 'Write the title for the heading.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),

				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'meta',
					'label'         => esc_html__( 'Meta', 'templaza-elements' ),
					'default'       => __('billed weekly', 'templaza-elements'),
					'description'   => esc_html__( 'Write the meta for the title.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'id'            => 'description',
					'label'         => esc_html__('Description', 'templaza-elements'),
					'type' => Controls_Manager::WYSIWYG,
					'default' => __( 'This plan is suitable for small businesses and offices.', 'templaza-elements' ),
					'placeholder' => __( 'Type your description here', 'templaza-elements' ),
					'separator'     => 'before',
				),

				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'price',
					'label'         => esc_html__( 'Price', 'templaza-elements' ),
					'default'       => __('69', 'templaza-elements'),
					'description'   => esc_html__( 'Define the price for price box', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'symbol',
					'label'         => esc_html__( 'Price Symbol', 'templaza-elements' ),
					'default'       => __('$', 'templaza-elements'),
					'description'   => esc_html__( 'Define the Symbol for price currency', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'label_text',
					'label'         => esc_html__( 'Highlight', 'templaza-elements' ),
					'default'       => __('Popular', 'templaza-elements'),
					'description'   => esc_html__( 'Indicate important notes and highlight parts of your content.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'id'            => 'label_styles',
					'type'          => Controls_Manager::SELECT,
					'label'         => __('Highlight Style', 'templaza-elements'),
					'options' => array(
						''          => __('Inherit', 'templaza-elements'),
						'uk-label-success' => __('Success', 'templaza-elements'),
						'uk-label-warning' => __('Warning', 'templaza-elements'),
						'uk-label-danger' => __('Danger', 'templaza-elements'),
						'uk-label-custom' => __('Custom', 'templaza-elements'),
					),
					'conditions' => [
						'terms' => [
							['name' => 'label_text', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'label_background_color',
					'label'         => esc_html__('Background Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Background of Highlight.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .tz-price-table_featured-inner' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'label_text', 'operator' => '!==', 'value' => ''],
							['name' => 'label_styles', 'operator' => '===', 'value' => 'uk-label-custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'label_color',
					'label'         => esc_html__('Label Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Highlight.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .tz-price-table_featured-inner' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'label_text', 'operator' => '!==', 'value' => ''],
							['name' => 'label_styles', 'operator' => '===', 'value' => 'uk-label-custom'],
						],
					],
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'label_font_family',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Label Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon label.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .tz-price-table_featured-inner',
					'conditions' => [
						'terms' => [
							['name' => 'label_text', 'operator' => '!==', 'value' => ''],
							['name' => 'label_styles', 'operator' => '===', 'value' => 'uk-label-custom'],
						],
					],
				),

				array(
					'type'      => Controls_Manager::REPEATER,
					'id'      => 'price_items',
					'label'     => esc_html__( 'Items', 'templaza-elements' ),
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'title' => 'Item',
						],
					],
					'title_field' => __( 'Item', 'templaza-elements' ),
				),

				//Link Settings
				array(
					'type'          => Controls_Manager::URL,
					'name'          => 'button_link',
					'label'         => __( 'Button Url', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					'default'       => [
						'url'       => '',
					],
					'separator'     => 'before',
				),
				array(
					'type'          => Controls_Manager::TEXT,
					'id'            => 'button_title',
					'label'         => esc_html__( 'Button Text', 'templaza-elements' ),
					'default'       => __('Learn More', 'templaza-elements'),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
					'conditions' => [
						'terms' => [
							['name' => 'button_link', 'operator' => '!==', 'value' => ''],
						],
					],
				),

				//Card Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_style',
					'label' => __( 'Card Style', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('None', 'templaza-elements'),
						'default' => __('Card Default', 'templaza-elements'),
						'primary' => __('Card Primary', 'templaza-elements'),
						'secondary' => __('Card Secondary', 'templaza-elements'),
						'hover' => __('Card Hover', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
					'start_section' => 'card',
					'section_name'      => esc_html__('Card Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background',
					'label'         => esc_html__('Card Background', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-pricing' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color',
					'label'         => esc_html__('Card Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-pricing' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_size',
					'label' => __( 'Card Size', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
				),
				array(
					'type'          => Controls_Manager::DIMENSIONS,
					'name'          =>  'card_padding',
					'label'         => __( 'Card Padding', 'templaza-elements' ),
					'responsive'    =>  true,
					'size_units'    => [ 'px', 'em', '%' ],
					'selectors'     => [
						'{{WRAPPER}} .ui-pricing-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_size', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'card_font_family',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Card Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-pricing',
				),

				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_tag',
					'label'         => esc_html__( 'Title tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
					),
					'default'       => 'h3',
					'description'   => esc_html__( 'Choose heading element.', 'templaza-elements' ),
					/* vc */
					'admin_label' => false,
					'start_section' => 'title_settings',
					'section_name'      => esc_html__('Title Settings', 'templaza-elements')
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'title_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon title.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-pricing .uk-card-title',
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'title_color',
					'label'         => esc_html__('Title Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of title.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-pricing .uk-card-title' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_heading_style',
					'default'       => 'h3',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Heading styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'title_heading_margin',
					'label'         => esc_html__('Title Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for title.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Meta Settings
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'meta_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Meta Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon title.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-pricing .plan-period',
					'start_section' => 'meta_settings',
					'section_name'      => esc_html__('Meta Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'meta_color',
					'label'         => esc_html__('Title Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of title.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-pricing .plan-period' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'meta_style',
					'default'       => '',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Meta styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
						'text-meta'         => esc_html__('Text Meta', 'templaza-elements'),
						'text-lead'         => esc_html__('Text Lead', 'templaza-elements'),
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'meta_margin',
					'label'         => esc_html__('Meta Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for title.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'meta_alignment',
					'label'         => esc_html__('Alignment', 'templaza-elements'),
					'description'   => esc_html__('Align the meta text above or below the title.', 'templaza-elements'),
					'options'       => array(
						'top' => __('Above Price', 'templaza-elements'),
						'' => __('Below Price', 'templaza-elements'),
						'inline' => __('Inline', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Description
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'description_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-pricing .plan-description',
					'start_section' => 'description_settings',
					'section_name'      => esc_html__('Description Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'description_color',
					'label'         => esc_html__('Description Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of description.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-pricing .plan-description' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'description_margin',
					'label'         => esc_html__('Description Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for description.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Price Settings
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'price_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Price Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon price.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-pricing .pricing-amount',
					'start_section' => 'price_settings',
					'section_name'      => esc_html__('Pricing Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'price_color',
					'label'         => esc_html__('Price Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of price.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-pricing .pricing-amount' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'price_style',
					'default'       => 'h3',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Price styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
						'text-meta'         => esc_html__('Text Meta', 'templaza-elements'),
						'text-lead'         => esc_html__('Text Lead', 'templaza-elements'),
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'price_margin',
					'label'         => esc_html__('Price Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for Price.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Symbol Settings
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'symbol_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Symbol Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon symbol.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .pricing-symbol',
					'start_section' => 'symbol_settings',
					'section_name'      => esc_html__('Symbol Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'symbol_color',
					'label'         => esc_html__('Symbol Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of symbol.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .pricing-symbol' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'symbol_style',
					'default'       => 'h3',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Symbol styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
						'text-meta'         => esc_html__('Text Meta', 'templaza-elements'),
						'text-lead'         => esc_html__('Text Lead', 'templaza-elements'),
					),
				),
				array(
					'id'          => 'symbol_margin',
					'label' => __( 'Currency Margin Top', 'plugin-domain' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 400,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],
					'selectors' => [
						'{{WRAPPER}} .pricing-symbol' => 'margin-top: {{SIZE}}{{UNIT}};',
					],
				),

				//Button Settings
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'button_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-button .uk-button',
					'start_section' => 'button_settings',
					'section_name'      => esc_html__('Button Settings', 'templaza-elements')
				),
				array(
					'name'          => 'button_style',
					'label' => __( 'Button Style', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements' ),
						'primary' => __('Primary', 'templaza-elements') ,
						'secondary' => __('Secondary', 'templaza-elements' ),
						'danger' => __('Danger', 'templaza-elements' ),
						'text' => __('Text', 'templaza-elements' ),
						'link' => __('Link', 'templaza-elements' ),
						'link-muted' => __('Link Muted', 'templaza-elements' ),
						'link-text' => __('Link Text', 'templaza-elements' ),
						'custom' => __('Custom', 'templaza-elements' ),
					],
				),
				array(
					'name'          => 'button_shape',
					'label' => __( 'Button Shape', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'rounded',
					'options' => [
						'rounded' => __('Rounded', 'templaza-elements' ),
						'square' => __('Square', 'templaza-elements' ),
						'circle' => __('Circle', 'templaza-elements' ),
						'pill' => __('Pill', 'templaza-elements' ),
					],
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-muted'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-text'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'text'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'button_full_width',
					'label'         => esc_html__('Full width button', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'button_size',
					'label'         => esc_html__('Button Size', 'templaza-elements'),
					'description'   => esc_html__('Set the size for multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'id'          => 'background_color',
					'label' => __( 'Background Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-button > a' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'id'          => 'color',
					'label' => __( 'Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ui-button > a' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'name' => 'border',
					'type' => \Elementor\Group_Control_Border::get_type(),
					'label' => __( 'Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-button > a',
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'id'          => 'hover_background_color',
					'label' => __( 'Hover Background Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-button > a:hover' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'id'          => 'hover_color',
					'label' => __( 'Hover Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ui-button > a:hover' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'name' => 'hover_border',
					'type' => \Elementor\Group_Control_Border::get_type(),
					'label' => __( 'Hover Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-button > a:hover',
					'conditions' => [
						'terms' => [
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'button_margin',
					'label'         => esc_html__('Button Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for Button.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}