<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UICard' ) ) {
	/**
	 * Class Templaza_Elements_Config_UICard
	 */
	class Templaza_Elements_Config_UICard extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uicard';
			self::$name = esc_html__( 'TemPlaza: UI Card', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Card Box.', 'templaza-elements' );
			self::$icon = 'eicon-featured-image';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			// options
			$options = array(
				array(
					'type'          => Controls_Manager::TEXTAREA,
					'name'          => 'title',
					'label'         => esc_html__( 'Title', 'templaza-elements' ),
					'default'       => __('Your Heading Text Here', 'templaza-elements'),
					'description'   => esc_html__( 'Write the title for the heading.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					/* vc */
					'admin_label'   => true,
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_tag',
					'label'         => esc_html__( 'Title tag', 'templaza-elements' ),
					'options'       => array(
						'h1'        => 'h1',
						'h2'        => 'h2',
						'h3'        => 'h3',
						'h4'        => 'h4',
						'h5'        => 'h5',
						'h6'        => 'h6',
						'div'       => 'div',
						'span'      => 'span',
						'p'         => 'p',
					),
					'default'       => 'h3',
					'description'   => esc_html__( 'Choose heading element.', 'templaza-elements' ),
					'condition'     => array(
						'title!'    => ''
					),
					/* vc */
					'admin_label' => false,
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'title_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon title.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-card .uk-card-title',
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'title_color',
					'label'         => esc_html__('Title Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of title.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-card .uk-card-title' => 'color: {{VALUE}}',
					],
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'title_heading_style',
					'default'       => 'h3',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Heading styles differ in font-size but may also come with a predefined color, size and font', 'templaza-elements'),
					'options'       => array(
						''                  => esc_html__('None', 'templaza-elements'),
						'heading-2xlarge'   => esc_html__('2XLarge', 'templaza-elements'),
						'heading-xlarge'    => esc_html__('XLarge', 'templaza-elements'),
						'heading-large'     => esc_html__('Large', 'templaza-elements'),
						'heading-medium'    => esc_html__('Medium', 'templaza-elements'),
						'heading-small'     => esc_html__('Small', 'templaza-elements'),
						'h1'                => esc_html__('H1', 'templaza-elements'),
						'h2'                => esc_html__('H2', 'templaza-elements'),
						'h3'                => esc_html__('H3', 'templaza-elements'),
						'h4'                => esc_html__('H4', 'templaza-elements'),
						'h5'                => esc_html__('H5', 'templaza-elements'),
						'h6'                => esc_html__('H6', 'templaza-elements'),
					),
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'title_position',
					'label'         => esc_html__('Icon/Image Position', 'templaza-elements'),
					'description'   => esc_html__('Set the icon/image position.', 'templaza-elements'),
					'options'       => array(
						'after'     => esc_html__('Before Title', 'templaza-elements'),
						'before'    => esc_html__('After Title', 'templaza-elements'),
					),
					'default'       => 'after',
					'condition'     => array(
						'title!'    => ''
					),
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'title_heading_margin',
					'label'         => esc_html__('Title Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for title.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
					'condition'     => array(
						'title!'    => ''
					),
				),
				//Content Settings
				array(
					'name'          => 'text',
					'label'         => esc_html__('Content', 'templaza-elements'),
					'type' => Controls_Manager::WYSIWYG,
					'default' => __( 'Default description', 'templaza-elements' ),
					'placeholder' => __( 'Type your description here', 'templaza-elements' ),
					'separator'     => 'before',
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'text_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-card .ui-card-text',
					'condition'     => array(
						'text!'    => ''
					),
				),

				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'layout_type',
					'label'         => esc_html__('Layout Type', 'templaza-elements'),
					'description'   => esc_html__('Select icon or image layout type from the list. Both option work for Icon/Image Position Left & Right only.', 'templaza-elements'),
					'options'       => array(
						'icon'      => esc_html__('Icon', 'templaza-elements'),
						'image'     => esc_html__('Image', 'templaza-elements'),
					),
					'default'       => 'icon',
					'separator'     => 'before',
				),

				//Icon Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'icon_type',
					'label' => __( 'Icon Type', 'templaza-elements' ),
					'default' => '',
					'options' => [
						''  => __( 'FontAwesome', 'templaza-elements' ),
						'uikit' => __( 'UIKit', 'templaza-elements' ),
					],
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'icon'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::ICONS,
					'name'          => 'icon',
					'label'         => esc_html__('Select Icon:', 'templaza-elements'),
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'icon'],
							['name' => 'icon_type', 'operator' => '===', 'value' => ''],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT2,
					'name'          => 'uikit_icon',
					'label'         => esc_html__('Select Icon:', 'templaza-elements'),
					'default' => '',
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'icon'],
							['name' => 'icon_type', 'operator' => '===', 'value' => 'uikit'],
						],
					],
					'options' => $this->get_font_uikit(),
				),
				array(
					'name'          => 'icon_size',
					'label' => __( 'Icon Size', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 400,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 64,
					],
					'selectors' => [
						'{{WRAPPER}} .ui-media' => 'font-size: {{SIZE}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'icon'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'icon_color',
					'label'         => esc_html__('Icon Color', 'templaza-elements'),
					'description'   => esc_html__('Set the color of Icon.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-media' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'icon'],
						],
					],
				),

				//Image Settings
				array(
					'type'          =>  Controls_Manager::MEDIA,
					'name'          => 'image',
					'label'         => esc_html__('Select Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'image_appear',
					'label' => __( 'Image Appear', 'templaza-elements' ),
					'default' => 'top',
					'options' => [
						'top'        => __( 'Top', 'templaza-elements' ),
						'inside'   => __( 'Inside', 'templaza-elements' ),
						'bottom'   => __( 'Bottom', 'templaza-elements' ),
					],
					'conditions' => [
						'terms' => [
							['name' => 'layout_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				),

				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'media_margin',
					'label'         => esc_html__('Media Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for Icon/Image.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
				),

				//Link Settings
				array(
					'type'          => Controls_Manager::URL,
					'name'          => 'link',
					'label'         => __( 'Title/Image/Icon/Button Url', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					'default'       => [
						'url'       => '',
					],
					'separator'     => 'before',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'url_appear',
					'label' => __( 'Url Appear', 'templaza-elements' ),
					'default' => 'button',
					'options' => [
						'button'        => __( 'Button', 'templaza-elements' ),
						'button_title'   => __( 'Button & Title', 'templaza-elements' ),
						'button_media'   => __( 'Button & Icon/Image', 'templaza-elements' ),
						'all'   => __( 'All', 'templaza-elements' ),
					],
					'conditions' => [
						'terms' => [
							['name' => 'link[url]', 'operator' => '!==', 'value' => ''],
						],
					],
				),

				//Card Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_style',
					'label' => __( 'Card Style', 'templaza-elements' ),
					'default' => '',
					'options' => [
						'' => __('None', 'templaza-elements'),
						'default' => __('Card Default', 'templaza-elements'),
						'primary' => __('Card Primary', 'templaza-elements'),
						'secondary' => __('Card Secondary', 'templaza-elements'),
						'hover' => __('Card Hover', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
					'start_section' => 'card',
					'section_name'      => esc_html__('Card Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background',
					'label'         => esc_html__('Card Background', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card.', 'templaza-elements'),
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-card' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color',
					'label'         => esc_html__('Card Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-card' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Border::get_type(),
					'name'          => 'card_border',
					'label'         => esc_html__('Card Border', 'templaza-elements'),
					'description'   => esc_html__('Set the Border of Card.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .ui-card',
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Box_Shadow::get_type(),
					'name'          => 'card_box_shadow',
					'label'         => esc_html__('Card Box Shadow', 'templaza-elements'),
					'description'   => esc_html__('Set the Box Shadow of Card.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .ui-card',
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background_hover',
					'label'         => esc_html__('Card Background Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card on mouse hover.', 'templaza-elements'),
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-card:hover' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color_hover',
					'label'         => esc_html__('Card Color Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card on mouse hover.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-card:hover' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Border::get_type(),
					'name'          => 'card_border_hover',
					'label'         => esc_html__('Card Border Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Border of Card on mouse hover.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .ui-card:hover',
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Box_Shadow::get_type(),
					'name'          => 'card_box_shadow_hover',
					'label'         => esc_html__('Card Box Shadow Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Box Shadow of Card hover.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .ui-card:hover',
					'conditions' => [
						'terms' => [
							['name' => 'card_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_size',
					'label' => __( 'Card Size', 'templaza-elements' ),
					'default' => '',
					'separator'     => 'before',
					'options' => [
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					],
				),
				array(
					'type'          => Controls_Manager::DIMENSIONS,
					'name'          =>  'card_padding',
					'label'         => __( 'Card Padding', 'templaza-elements' ),
					'responsive'    =>  true,
					'size_units'    => [ 'px', 'em', '%' ],
					'selectors'     => [
						'{{WRAPPER}} .uk-card-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_size', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),

				//Button Settings
				array(
					'type'          => Controls_Manager::TEXTAREA,
					'name'          => 'button_text',
					'label'         => esc_html__( 'Button Text', 'templaza-elements' ),
					'description'   => esc_html__( 'Enter button texts here. Leave blank if no button is required.', 'templaza-elements' ),
					'dynamic'       => [
						'active'    => true,
					],
					'start_section' => 'button',
					'section_name'      => esc_html__('Button Settings', 'templaza-elements')
				),
				array(
					'type'          => Group_Control_Typography::get_type(),
					'name'          => 'button_typography',
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-button .uk-button',
					'condition'     => array(
						'button_text!'    => ''
					),
				),
				array(
					'name'          => 'button_style',
					'label' => __( 'Button Style', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements' ),
						'primary' => __('Primary', 'templaza-elements') ,
						'secondary' => __('Secondary', 'templaza-elements' ),
						'danger' => __('Danger', 'templaza-elements' ),
						'text' => __('Text', 'templaza-elements' ),
						'link' => __('Link', 'templaza-elements' ),
						'link-muted' => __('Link Muted', 'templaza-elements' ),
						'link-text' => __('Link Text', 'templaza-elements' ),
						'custom' => __('Custom', 'templaza-elements' ),
					],
					'condition'     => array(
						'button_text!'    => ''
					),
				),
				array(
					'name'          => 'button_shape',
					'label' => __( 'Button Shape', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'rounded',
					'options' => [
						'rounded' => __('Rounded', 'templaza-elements' ),
						'square' => __('Square', 'templaza-elements' ),
						'round' => __('Round', 'templaza-elements' ),
					],
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'button_text', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-muted'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-text'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'text'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'button_size',
					'label'         => esc_html__('Button Size', 'templaza-elements'),
					'description'   => esc_html__('Set the size for multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'type'          =>  Controls_Manager::SELECT,
					'name'          => 'button_margin',
					'label'         => esc_html__('Button Margin', 'templaza-elements'),
					'description'   => esc_html__('Set the vertical margin for Button.', 'templaza-elements'),
					'options'       => array(
						''          => esc_html__('Inherit', 'templaza-elements'),
						'default'   => esc_html__('Default', 'templaza-elements'),
						'small'     => esc_html__('Small', 'templaza-elements'),
						'medium'    => esc_html__('Medium', 'templaza-elements'),
						'large'     => esc_html__('Large', 'templaza-elements'),
						'xlarge'    => esc_html__('X-Large', 'templaza-elements'),
						'remove'    => esc_html__('None', 'templaza-elements'),
					),
					'default'       => '',
					'condition'     => array(
						'button_text!'    => ''
					),
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}