<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIIcon' ) ) {
	/**
	 * Class Templaza_Elements_Config_UI_Button
	 */
	class Templaza_Elements_Config_UIIcon extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uiicon';
			self::$name = esc_html__( 'TemPlaza: UI Icon', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Icon.', 'templaza-elements' );
			self::$icon = 'eicon-star';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'icon_type',
				[
					'label' => __( 'Icon Type', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						''  => __( 'FontAwesome', 'templaza-elements' ),
						'uikit' => __( 'UIKit', 'templaza-elements' ),
					],
				]
			);
			$repeater->add_control(
				'icon',
				[
					'label' => __( 'Select Icon:', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'conditions' => [
						'terms' => [
							['name' => 'icon_type', 'operator' => '===', 'value' => ''],
						],
					],
				]
			);
			$repeater->add_control(
				'uikit_icon',
				[
					'label' => __( 'Select Icon:', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SELECT2,
					'default' => '',
					'conditions' => [
						'terms' => [
							['name' => 'icon_type', 'operator' => '===', 'value' => 'uikit'],
						],
					],
					'options' => $this->get_font_uikit(),
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'templaza-elements' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);
			// options
			$options = array(
				array(
					'type'      => Controls_Manager::REPEATER,
					'id'      => 'uiicons',
					'label'     => esc_html__( 'Icons', 'templaza-elements' ),
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'text' => 'Icon Item',
						],
					],
					'title_field' => __( 'Icon Item', 'templaza-elements' ),
				),
				array(
					'name'          => 'icon_size',
					'label' => __( 'Icon Size', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'responsive' => true,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 400,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 64,
					],
					'selectors' => [
						'{{WRAPPER}} a.ui-icon' => 'font-size: {{SIZE}}{{UNIT}};',
					],
					'start_section' => 'misc',
					'section_name'      => esc_html__('Misc Settings', 'templaza-elements')
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'hover_animation',
					'label'         => esc_html__('Hover Animation', 'templaza-elements'),
					'description'   => esc_html__('A collection of smooth animations to use within your page.', 'templaza-elements'),
					'options'       => array(
						'' => __('Inherit', 'templaza-elements'),
						'fade' => __('Fade', 'templaza-elements'),
						'scale-up' => __('Scale Up', 'templaza-elements'),
						'scale-down' => __('Scale Down', 'templaza-elements'),
						'slide-top-small' => __('Slide Top Small', 'templaza-elements'),
						'slide-bottom-small' => __('Slide Bottom Small', 'templaza-elements'),
						'slide-left-small' => __('Slide Left Small', 'templaza-elements'),
						'slide-right-small' => __('Slide Right Small', 'templaza-elements'),
						'slide-top-medium' => __('Slide Top Medium', 'templaza-elements'),
						'slide-bottom-medium' => __('Slide Bottom Medium', 'templaza-elements'),
						'slide-left-medium' => __('Slide Left Medium', 'templaza-elements'),
						'slide-right-medium' => __('Slide Right Medium', 'templaza-elements'),
						'slide-top' => __('Slide Top 100%', 'templaza-elements'),
						'slide-bottom' => __('Slide Bottom 100%', 'templaza-elements'),
						'slide-left' => __('Slide Left 100%', 'templaza-elements'),
						'slide-right' => __('Slide Right 100%', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'id'    =>  'background_color',
					'label' => __( 'Background Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} a.ui-icon' => 'background-color: {{VALUE}}',
					],
				),
				array(
					'id'    =>  'color',
					'label' => __( 'Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} a.ui-icon' => 'color: {{VALUE}}',
					],
				),
				array(
					'type' => \Elementor\Group_Control_Border::get_type(),
					'name' => 'border',
					'label' => __( 'Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} a.ui-icon',
				),
				array(
					'id'          => 'border_radius',
					'label' => __( 'Border Radius', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 400,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 10,
					],
					'selectors' => [
						'{{WRAPPER}} a.ui-icon' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				),
				array(
					'id'          => 'padding',
					'label' => __( 'Padding', 'templaza-elements' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} a.ui-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				),
				array(
					'id'    =>  'hover_background_color',
					'label' => __( 'Hover Background Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} a.ui-icon:hover' => 'background-color: {{VALUE}}',
					],
				),
				array(
					'id'    =>  'hover_color',
					'label' => __( 'Hover Color', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} a.ui-icon:hover' => 'color: {{VALUE}}',
					],
				),
				array(
					'type' => \Elementor\Group_Control_Border::get_type(),
					'name' => 'hover_border',
					'label' => __( 'Hover Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} a.ui-icon:hover',
				),
				array(
					'id'          => 'hover_border_radius',
					'label' => __( 'Hover Border Radius', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 400,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 10,
					],
					'selectors' => [
						'{{WRAPPER}} a.ui-icon:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
					],
				),
				array(
					'id'          => 'hover_padding',
					'label' => __( 'Hover Padding', 'templaza-elements' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors' => [
						'{{WRAPPER}} a.ui-icon:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'grid_column_gap',
					'label'         => esc_html__('Column Gap', 'templaza-elements'),
					'description'   => esc_html__('Set the size of the column gap between multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'separator'     => 'before',
					'default'           => 'small',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'grid_row_gap',
					'label'         => esc_html__('Row Gap', 'templaza-elements'),
					'description'   => esc_html__('Set the size of the row gap between multiple buttons.', 'templaza-elements'),
					'options'       => array(
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
					),
					'default'           => 'small',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}