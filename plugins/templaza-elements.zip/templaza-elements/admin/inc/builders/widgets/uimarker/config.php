<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIMarker' ) ) {
	/**
	 * Class Templaza_Elements_Config_UI_Marker
	 */
	class Templaza_Elements_Config_UIMarker extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uimarker';
			self::$name = esc_html__( 'TemPlaza: UI Marker', 'templaza-elements' );
			self::$desc = esc_html__( 'Create a marker icon that can be displayed on top of images.', 'templaza-elements' );
			self::$icon = 'eicon-post';
			parent::__construct();

		}

		public function get_scripts() {
			return array(
				'ui-marker-script' => array(
					'src'   =>  'script.min.js',
					'deps'  =>  array('jquery')
				)
			);
		}

		/**
		 * @return array
		 */
		public function get_options() {
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'left_space', [
					'label' => __( 'Left', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ '%' ],
					'range' => [
						'%' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 50,
					],
					'selectors' => [
						'{{WRAPPER}} .ui-popover-items {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$repeater->add_control(
				'top_space', [
					'label' => __( 'Top', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ '%' ],
					'range' => [
						'%' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 50,
					],
					'selectors' => [
						'{{WRAPPER}} .ui-popover-items {{CURRENT_ITEM}}' => 'Top: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$repeater->add_control(
				'use_animation',
				[
					'label' => __( 'Use Animation', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '0',
					'separator'     => 'before',
				]
			);
			$repeater->add_control(
				'delay',
				[
					'label' => __( 'Delay', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'min' => 100,
					'max' => 5000,
					'step' => 100,
					'default' => 500,
					'conditions' => [
						'terms' => [
							['name' => 'use_animation', 'operator' => '===', 'value' => '1'],
						],
					],
				]
			);
			$repeater->add_control(
				'repeat_animation',
				[
					'label' => __( 'Repeat Animation', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Yes', 'templaza-elements' ),
					'label_off' => __( 'No', 'templaza-elements' ),
					'return_value' => '1',
					'default' => '0',
					'conditions' => [
						'terms' => [
							['name' => 'use_animation', 'operator' => '===', 'value' => '1'],
						],
					],
				]
			);
			$repeater->add_control(
				'marker_type',
				[
					'label' => __( 'Marker Type', 'templaza-elements' ),
					'description'   => esc_html__('Select a different type for this item.', 'templaza-elements'),
					'type' => Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'' => __('Point', 'templaza-elements'),
						'image' => __('Image', 'templaza-elements'),
					],
					'separator'     => 'before',
				]
			);
			$repeater->add_control(
				'marker_point_image',
				[
					'type'          =>  Controls_Manager::MEDIA,
					'label'         => esc_html__('Select Point Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Image_Size::get_type(),
				[
					'name' => 'marker_point_image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [ 'custom' ],
					'include' => [],
					'default' => 'full',
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				]
			);
			$repeater->add_responsive_control(
				'marker_point_image_width',
				[
					'label' => __( 'Point Image Size', 'templaza-elements' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 50,
					],
					'selectors' => [
						'{{WRAPPER}} .ui-marker-image{{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'marker_point_image_border',
					'label' => __( 'Point Image Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-marker-image{{CURRENT_ITEM}}',
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
					'separator'     => 'before',
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'marker_point_image_box_shadow',
					'label' => __( 'Box Shadow', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-marker-image{{CURRENT_ITEM}}',
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'marker_point_image_border_hover',
					'label' => __( 'Point Image Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-marker-image{{CURRENT_ITEM}}:hover',
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
					'separator'     => 'before',
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'marker_point_image_box_shadow_hover',
					'label' => __( 'Box Shadow', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-marker-image{{CURRENT_ITEM}}:hover',
					'conditions' => [
						'terms' => [
							['name' => 'marker_type', 'operator' => '===', 'value' => 'image'],
						],
					],
				]
			);
			$repeater->add_control(
				'marker_title', [
					'label' => __( 'Title', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
					'separator'     => 'before',
				]
			);
			$repeater->add_control(
				'marker_meta', [
					'label' => __( 'Meta', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'marker_content', [
					'label'         => esc_html__('Content', 'templaza-elements'),
					'type' => Controls_Manager::WYSIWYG,
					'default' => __( 'Default description', 'templaza-elements' ),
					'placeholder' => __( 'Type your description here', 'templaza-elements' ),
					/* vc */
					'admin_label'   => true,
				]
			);
			$repeater->add_control(
				'marker_image',
				[
					'type'          =>  Controls_Manager::MEDIA,
					'label'         => esc_html__('Select Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Image_Size::get_type(),
				[
					'name' => 'marker_image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [ 'custom' ],
					'include' => [],
					'default' => 'full',
				]
			);
			$repeater->add_control(
				'marker_position',
				[
					'label' => __( 'Position', 'templaza-elements' ),
					'description'   => esc_html__('Select a different position for this item.', 'templaza-elements'),
					'type' => Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'' => __('None', 'templaza-elements'),
						'top-center' => __('Top', 'templaza-elements'),
						'bottom-center' => __('Bottom', 'templaza-elements'),
						'left-center' => __('Left', 'templaza-elements'),
						'right-center' => __('Right', 'templaza-elements'),
					],
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'templaza-elements' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'templaza-elements' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);
			$repeater->add_control(
				'button_title', [
					'label' => __( 'Button Title', 'templaza-elements' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'button_style',
				[
					'label' => __( 'Button Style', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'default' => '',
					'options' => [
						'' => __('Default', 'templaza-elements' ),
						'primary' => __('Primary', 'templaza-elements') ,
						'secondary' => __('Secondary', 'templaza-elements' ),
						'danger' => __('Danger', 'templaza-elements' ),
						'text' => __('Text', 'templaza-elements' ),
						'link' => __('Link', 'templaza-elements' ),
						'link-muted' => __('Link Muted', 'templaza-elements' ),
						'link-text' => __('Link Text', 'templaza-elements' ),
						'custom' => __('Custom', 'templaza-elements' ),
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
						],
					],
				]
			);
			$repeater->add_control(
				'button_shape',
				[
					'label' => __( 'Button Shape', 'templaza-elements' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'rounded',
					'options' => [
						'rounded' => __('Rounded', 'templaza-elements' ),
						'square' => __('Square', 'templaza-elements' ),
						'round' => __('Round', 'templaza-elements' ),
					],
					'conditions' => [
						'relation' => 'and',
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-muted'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'link-text'],
							['name' => 'button_style', 'operator' => '!==', 'value' => 'text'],
						],
					],
				]
			);
			$repeater->add_control(
				'button_background_color',
				[
					'label' => __( 'Button Background Color', 'templaza-elements' ),
					'type' => Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_control(
				'button_color',
				[
					'label' => __( 'Button Color', 'templaza-elements' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => __( 'Button Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a',
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_control(
				'button_hover_background_color',
				[
					'label' => __( 'Button Hover Background Color', 'templaza-elements' ),
					'type' => Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a:hover' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_control(
				'button_hover_color',
				[
					'label' => __( 'Button Hover Color', 'templaza-elements' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a:hover' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			$repeater->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_hover_border',
					'label' => __( 'Button Hover Border', 'templaza-elements' ),
					'selector' => '{{WRAPPER}} .ui-buttons {{CURRENT_ITEM}} > a:hover',
					'conditions' => [
						'terms' => [
							['name' => 'button_title', 'operator' => '!==', 'value' => ''],
							['name' => 'button_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				]
			);
			// options
			$options = array(
				//Image Settings
				array(
					'type'          =>  Controls_Manager::MEDIA,
					'id'            => 'image',
					'label'         => esc_html__('Select Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Image_Size::get_type(),
					'name'        => 'image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [ 'custom' ],
					'include' => [],
					'default' => 'full',
				),
				array(
					'type'      => Controls_Manager::REPEATER,
					'id'        => 'uimarker_items',
					'label'     => esc_html__( 'Marker Items', 'templaza-elements' ),
					'fields'    => $repeater->get_controls(),
					'default' => [
						[
							'marker_title' => 'Marker Item',
						],
					],
					'title_field' => __( 'Marker Item', 'templaza-elements' ),
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'popover_mode',
					'label'         => esc_html__('Mode', 'templaza-elements'),
					'description'   => esc_html__('Display the popover on click or hover', 'templaza-elements'),
					'options'       => array(
						'hover' => __('Hover', 'templaza-elements'),
						'click' => __('Click', 'templaza-elements'),
					),
					'default'           => 'hover',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'popover_position',
					'label'         => esc_html__('Position', 'templaza-elements'),
					'description'   => esc_html__('Select the popover\'s alignment to its marker. If the popover doesn\'t fit its container, it will flip automatically.', 'templaza-elements'),
					'options'       => array(
						'top-center' => __('Top', 'templaza-elements'),
						'bottom-center' => __('Bottom', 'templaza-elements'),
						'left-center' => __('Left', 'templaza-elements'),
						'right-center' => __('Right', 'templaza-elements'),
					),
					'default'           => 'top-center',
				),
				array(
					'id'            => 'popover_width',
					'label'         => __( 'Width', 'templaza-elements' ),
					'type'          => Controls_Manager::SLIDER,
					'size_units'    => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ui-addon-marker .uk-drop' => 'width: {{SIZE}}{{UNIT}};',
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'popover_animation',
					'label'         => esc_html__('Animation', 'templaza-elements'),
					'description'   => esc_html__('Apply the animations effect to the dropdown on hover/click', 'templaza-elements'),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'fade' => __('Fade', 'templaza-elements'),
						'scale-up' => __('Scale Up', 'templaza-elements'),
						'scale-down' => __('Scale Down', 'templaza-elements'),
						'slide-top-small' => __('Slide Top Small', 'templaza-elements'),
						'slide-bottom-small' => __('Slide Bottom Small', 'templaza-elements'),
						'slide-left-small' => __('Slide Left Small', 'templaza-elements'),
						'slide-right-small' => __('Slide Right Small', 'templaza-elements'),
						'slide-top-medium' => __('Slide Top Medium', 'templaza-elements'),
						'slide-bottom-medium' => __('Slide Bottom Medium', 'templaza-elements'),
						'slide-left-medium' => __('Slide Left Medium', 'templaza-elements'),
						'slide-right-medium' => __('Slide Right Medium', 'templaza-elements'),
						'slide-top' => __('Slide Top 100%', 'templaza-elements'),
						'slide-bottom' => __('Slide Bottom 100%', 'templaza-elements'),
						'slide-left' => __('Slide Left 100%', 'templaza-elements'),
						'slide-right' => __('Slide Right 100%', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'card_styles',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Select a card style.', 'templaza-elements'),
					'options'       => array(
						'default' => __('Default', 'templaza-elements'),
						'primary' => __('Primary', 'templaza-elements'),
						'secondary' => __('Secondary', 'templaza-elements'),
					),
					'default'           => '',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'card_size',
					'label'         => esc_html__('Padding', 'templaza-elements'),
					'description'   => esc_html__('Define the card\'s size by selecting the padding between the card and its content.', 'templaza-elements'),
					'options'       => array(
						'uk-card-small' => __('Small', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'uk-card-large' => __('Large', 'templaza-elements'),
					),
					'default'           => 'uk-card-small',
				),
				array(
					'id'            => 'marker_background',
					'label'         => __( 'Background Color', 'templaza-elements' ),
					'type'          => Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors'     => [
						'{{WRAPPER}} .ui-buttons' => 'background-color: {{VALUE}}',
					],
				),
				array(
					'id'            => 'marker_color',
					'label'         => __( 'Marker Color', 'templaza-elements' ),
					'type'          => Controls_Manager::COLOR,
					'separator'     => 'before',
					'selectors'     => [
						'{{WRAPPER}} .ui-buttons' => 'color: {{VALUE}}',
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'mobile_switcher',
					'label'         => esc_html__('Enable Mobile Switcher', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),

				//Title configure
				array(
					'name'            => 'title_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-text .ui-text-subtitle',
					'start_section' => 'title',
					'section_name'      => esc_html__('Title Settings', 'templaza-elements')
				),
				array(
					'id'            => 'heading_style',
					'type'          => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Title styles differ in font-size but may also come with a predefined color, size and font.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'heading-small' => __('Small', 'templaza-elements'),
						'h1' => __('H1', 'templaza-elements'),
						'h2' => __('H2', 'templaza-elements'),
						'h3' => __('H3', 'templaza-elements'),
						'h4' => __('H4', 'templaza-elements'),
						'h5' => __('H5', 'templaza-elements'),
						'h6' => __('H6', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'link_title',
					'type'          => Controls_Manager::SWITCHER,
					'label' => __('Link Title', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'id'            => 'title_hover_style',
					'type'          => Controls_Manager::SELECT,
					'label'         => __('Hover Style', 'templaza-elements'),
					'description'   => __('Set the hover style for a linked title.', 'templaza-elements'),
					'options' => array(
						'reset' => __('None', 'templaza-elements'),
						'heading' => __('Heading Link', 'templaza-elements'),
						'' => __('Default Link', 'templaza-elements'),
					),
					'default' => 'reset',
					'condition' => array(
						'link_title!'    => ''
					),
				),
				array(
					'id'            => 'title_decoration',
					'type'          => Controls_Manager::SELECT,
					'label'         => __('Decoration', 'templaza-elements'),
					'description'   => __('Decorate the title with a divider, bullet or a line that is vertically centered to the heading.', 'templaza-elements'),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-heading-divider' => __('Divider', 'templaza-elements'),
						'uk-heading-bullet' => __('Bullet', 'templaza-elements'),
						'uk-heading-line' => __('Line', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'title_color',
					'type'          => Controls_Manager::SELECT,
					'label'         => __('Predefined Color', 'templaza-elements'),
					'description'   => __('Select the predefined title text color.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'muted' => __('Muted', 'templaza-elements'),
						'emphasis' => __('Emphasis', 'templaza-elements'),
						'primary' => __('Primary', 'templaza-elements'),
						'secondary' => __('Secondary', 'templaza-elements'),
						'success' => __('Success', 'templaza-elements'),
						'warning' => __('Warning', 'templaza-elements'),
						'danger' => __('Danger', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'custom_title_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'color: {{VALUE}}',
					],
					'condition'     => array(
						'title_color'    => ''
					),
				),
				array(
					'id'            => 'title_text_transform',
					'type'          => Controls_Manager::SELECT,
					'label' => __('Transform', 'templaza-elements'),
					'description' => __('The following options will transform text into uppercased, capitalized or lowercased characters.', 'templaza-elements'),
					'options' => array(
						'' => __('Inherit', 'templaza-elements'),
						'uppercase' => __('Uppercase', 'templaza-elements'),
						'capitalize' => __('Capitalize', 'templaza-elements'),
						'lowercase' => __('Lowercase', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'heading_selector',
					'type' => Controls_Manager::SELECT,
					'label' => __('HTML Element', 'templaza-elements'),
					'description' => __('Choose one of the six heading elements to fit your semantic structure.', 'templaza-elements'),
					'options' => array(
						'h1' => __('h1', 'templaza-elements'),
						'h2' => __('h2', 'templaza-elements'),
						'h3' => __('h3', 'templaza-elements'),
						'h4' => __('h4', 'templaza-elements'),
						'h5' => __('h5', 'templaza-elements'),
						'h6' => __('h6', 'templaza-elements'),
						'div' => __('div', 'templaza-elements'),
					),
					'default' => 'h3',
				),
				array(
					'id'    => 'title_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Title Margin', 'templaza-elements'),
					'description' => __('Set the Title margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),
				
				//Meta Settings
				array(
					'name'            => 'meta_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Meta Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-meta',
					'start_section' => 'meta',
					'section_name'      => esc_html__('Meta Settings', 'templaza-elements')
				),
				array(
					'id'        => 'meta_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Select a predefined meta text style, including color, size and font-family.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'text-meta' => __('Meta', 'templaza-elements'),
						'h1' => __('H1', 'templaza-elements'),
						'h2' => __('H2', 'templaza-elements'),
						'h3' => __('H3', 'templaza-elements'),
						'h4' => __('H4', 'templaza-elements'),
						'h5' => __('H5', 'templaza-elements'),
						'h6' => __('H6', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'    => 'meta_color',
					'type' => Controls_Manager::SELECT,
					'label' => __('Predefined Color', 'templaza-elements'),
					'description' => __('Select the predefined meta text color.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'muted' => __('Muted', 'templaza-elements'),
						'emphasis' => __('Emphasis', 'templaza-elements'),
						'primary' => __('Primary', 'templaza-elements'),
						'secondary' => __('Secondary', 'templaza-elements'),
						'success' => __('Success', 'templaza-elements'),
						'warning' => __('Warning', 'templaza-elements'),
						'danger' => __('Danger', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'    => 'custom_meta_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-meta' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'meta_color'    => ''
					),
				),
				array(
					'id'    =>  'meta_text_transform',
					'type' => Controls_Manager::SELECT,
					'label' => __('Transform', 'templaza-elements'),
					'description' => __('The following options will transform text into uppercased, capitalized or lowercased characters.', 'templaza-elements'),
					'options' => array(
						'' => __('Inherit', 'templaza-elements'),
						'uppercase' => __('Uppercase', 'templaza-elements'),
						'capitalize' => __('Capitalize', 'templaza-elements'),
						'lowercase' => __('Lowercase', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'    => 'meta_element',
					'type' => Controls_Manager::SELECT,
					'label' => __('HTML Element', 'templaza-elements'),
					'description' => __('Choose one of the HTML elements to fit your semantic structure.', 'templaza-elements'),
					'options' => array(
						'h1' => __('h1', 'templaza-elements'),
						'h2' => __('h2', 'templaza-elements'),
						'h3' => __('h3', 'templaza-elements'),
						'h4' => __('h4', 'templaza-elements'),
						'h5' => __('h5', 'templaza-elements'),
						'h6' => __('h6', 'templaza-elements'),
						'div' => __('div', 'templaza-elements'),
					),
					'default' => 'div',
				),
				array(
					'id'    => 'meta_alignment',
					'type' => Controls_Manager::SELECT,
					'label' => __('Alignment', 'templaza-elements'),
					'description' => __('Align the meta text above or below the title.', 'templaza-elements'),
					'options' => array(
						'top' => __('Above Title', 'templaza-elements'),
						'' => __('Below Title', 'templaza-elements'),
						'above' => __('Above Content', 'templaza-elements'),
						'content' => __('Below Content', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'    => 'meta_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'name'          => 'content_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-content',
					'start_section' => 'content',
					'section_name'      => esc_html__('Content Settings', 'templaza-elements')
				),
				array(
					'id'    => 'content_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Select a predefined text style, including color, size and font-family.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'text-lead' => __('Lead', 'templaza-elements'),
						'text-meta' => __('Meta', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'content_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'color: {{VALUE}}',
					],
				),
				array(
					'id'    => 'content_text_transform',
					'type' => Controls_Manager::SELECT,
					'label' => __('Transform', 'templaza-elements'),
					'description' => __('The following options will transform text into uppercased, capitalized or lowercased characters.', 'templaza-elements'),
					'options' => array(
						'' => __('Inherit', 'templaza-elements'),
						'uppercase' => __('Uppercase', 'templaza-elements'),
						'capitalize' => __('Capitalize', 'templaza-elements'),
						'lowercase' => __('Lowercase', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'    => 'content_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),

				//Button settings
				array(
					'id'    => 'all_button_title',
					'label' => __( 'Text', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
					'start_section' => 'button',
					'section_name'      => esc_html__('Button Settings', 'templaza-elements')
				),
				array(
					'id'    => 'link_new_tab',
					'type' => Controls_Manager::SELECT,
					'label' => __('Link New Tab', 'templaza-elements'),
					'options' => array(
						'' => __('Same Window', 'templaza-elements'),
						'_blank' => __('New Window', 'templaza-elements'),
					),
				),
				array(
					'id'    => 'link_button_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Set the button style.', 'templaza-elements'),
					'options' => array(
						'' => __('Button Default', 'templaza-elements'),
						'primary' => __('Button Primary', 'templaza-elements'),
						'secondary' => __('Button Secondary', 'templaza-elements'),
						'danger' => __('Button Danger', 'templaza-elements'),
						'text' => __('Button Text', 'templaza-elements'),
						'link' => __('Link', 'templaza-elements'),
						'link-muted' => __('Link Muted', 'templaza-elements'),
						'link-text' => __('Link Text', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'name'          => 'button_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-text .ui-text-subtitle',
					'condition' => array(
						'link_button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_background',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Background Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'background-color: {{VALUE}}',
					],
					'default' => '#1e87f0',
					'condition' => array(
						'link_button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Button Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'link_button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_background_hover',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Hover Background Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'background-color: {{VALUE}}',
					],
					'default' => '#0f7ae5',
					'condition' => array(
						'link_button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_hover_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Hover Button Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-text .ui-text-subtitle' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'link_button_style'    => 'custom'
					),
				),
				array(
					'id'    => 'link_button_size',
					'type' => Controls_Manager::SELECT,
					'label' => __('Button Size', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'uk-button-small' => __('Small', 'templaza-elements'),
						'uk-button-large' => __('Large', 'templaza-elements'),
					),
				),
				array(
					'id'    => 'button_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}