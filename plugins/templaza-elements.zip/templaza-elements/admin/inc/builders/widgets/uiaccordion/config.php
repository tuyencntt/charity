<?php
/**
 * Templaza_Elements Heading config class
 *
 * @version     1.0.0
 * @author      TemPlaza
 * @package     Templaza_Elements/Classes
 * @category    Classes
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! class_exists( 'Templaza_Elements_Config_UIAccordion' ) ) {
	/**
	 * Class Templaza_Elements_Config_UI_Button
	 */
	class Templaza_Elements_Config_UIAccordion extends Templaza_Elements_Abstract_Config {

		/**
		 * Templaza_Elements_Config_Heading constructor.
		 */
		public function __construct() {
			// info
			self::$base = 'uiaccordion';
			self::$name = esc_html__( 'TemPlaza: UI Accordion', 'templaza-elements' );
			self::$desc = esc_html__( 'Add UI Accordion.', 'templaza-elements' );
			self::$icon = 'eicon-accordion';
			parent::__construct();

		}

		/**
		 * @return array
		 */
		public function get_options() {
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'title', [
					'label' => __( 'Title', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'content',
				[
					'label'         => esc_html__('Content', 'templaza-elements'),
					'type' => Controls_Manager::WYSIWYG,
					'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras in semper sem. Praesent elit erat, suscipit sed varius ut, porta sit amet lorem. Duis eget vulputate turpis. Vivamus maximus ac nisl vel suscipit.', 'templaza-elements' ),
					'placeholder' => __( 'Type your description here', 'templaza-elements' ),
				]
			);
			$repeater->add_control(
				'image',
				[
					'type'          =>  Controls_Manager::MEDIA,
					'label'         => esc_html__('Select Image:', 'templaza-elements'),
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);
			$repeater->add_control(
				\Elementor\Group_Control_Image_Size::get_type(),
				[
					'name' => 'image', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
					'exclude' => [],
					'include' => [],
					'default' => 'large',
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'templaza-elements' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
					],
				]
			);
			$repeater->add_control(
				'link_title', [
					'label' => __( 'Link Title', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '' , 'templaza-elements' ),
					'label_block' => true,
				]
			);
			// options
			$options = array(
				array(
					'type'      => Controls_Manager::REPEATER,
					'name'      => 'uiaccordions',
					'label'     => esc_html__( 'Items', 'templaza-elements' ),
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'title' => 'Item',
						],
					],
					'title_field' => __( 'Item', 'templaza-elements' ),
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'multiple',
					'label'         => esc_html__('Allow multiple open items', 'templaza-elements'),
					'desc'          => __('To display multiple content sections at the same time without one collapsing when the other one is opened', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'closed',
					'label'         => esc_html__('Allow all items to be closed', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '1',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'icon_align',
					'label'         => esc_html__('Left Icon Alignment', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'accordion_style',
					'label'         => esc_html__('Style', 'templaza-elements'),
					'description'   => esc_html__('Select a predefined style for accordion', 'templaza-elements'),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'default' => __('Default', 'templaza-elements'),
						'muted' => __('Muted', 'templaza-elements'),
						'primary' => __('Primary', 'templaza-elements'),
						'secondary' => __('Secondary', 'templaza-elements'),
						'hover' => __('Hover', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					),
					'default'           => '',
					'start_section' => 'card_settings',
					'section_name'      => esc_html__('Card Settings', 'templaza-elements')
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background',
					'label'         => esc_html__('Card Background', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card.', 'templaza-elements'),
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .tz-item' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color',
					'label'         => esc_html__('Card Color', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .tz-item' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Border::get_type(),
					'name'          => 'card_border',
					'label'         => esc_html__('Card Border', 'templaza-elements'),
					'description'   => esc_html__('Set the Border of Card.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .tz-item',
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Box_Shadow::get_type(),
					'name'          => 'card_box_shadow',
					'label'         => esc_html__('Card Box Shadow', 'templaza-elements'),
					'description'   => esc_html__('Set the Box Shadow of Card.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .tz-item',
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_background_hover',
					'label'         => esc_html__('Card Background Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Background Color of Card on mouse hover.', 'templaza-elements'),
					'separator'     => 'before',
					'selectors' => [
						'{{WRAPPER}} .tz-item:hover' => 'background-color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  Controls_Manager::COLOR,
					'name'          => 'card_color_hover',
					'label'         => esc_html__('Card Color Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Color of Card on mouse hover.', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .tz-item:hover' => 'color: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Border::get_type(),
					'name'          => 'card_border_hover',
					'label'         => esc_html__('Card Border Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Border of Card on mouse hover.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .tz-item:hover',
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          =>  \Elementor\Group_Control_Box_Shadow::get_type(),
					'name'          => 'card_box_shadow_hover',
					'label'         => esc_html__('Card Box Shadow Hover', 'templaza-elements'),
					'description'   => esc_html__('Set the Box Shadow of Card hover.', 'templaza-elements'),
					'selector' => '{{WRAPPER}} .tz-item:hover',
					'conditions' => [
						'terms' => [
							['name' => 'accordion_style', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),
				array(
					'type'          => Controls_Manager::SELECT,
					'name'          => 'card_size',
					'label'         => esc_html__('Size', 'templaza-elements'),
					'description'   => esc_html__('Define the card\'s size by selecting the padding between the card and its content.', 'templaza-elements'),
					'options'       => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					),
					'default'           => 'small',
					'condition'     => array(
						'accordion_style!'    => ''
					),
				),
				array(
					'type'          => Controls_Manager::DIMENSIONS,
					'name'          =>  'card_padding',
					'label'         => __( 'Card Padding', 'templaza-elements' ),
					'responsive'    =>  true,
					'size_units'    => [ 'px', 'em', '%' ],
					'selectors'     => [
						'{{WRAPPER}} .uk-card-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'conditions' => [
						'terms' => [
							['name' => 'card_size', 'operator' => '===', 'value' => 'custom'],
						],
					],
				),

				//Title configure
				array(
					'name'            => 'title_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Title Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .tz-title',
					'start_section' => 'title_settings',
					'section_name'      => esc_html__('Title Settings', 'templaza-elements')
				),
				array(
					'id'            => 'title_color',
					'type'          => Controls_Manager::SELECT,
					'label'         => __('Predefined Color', 'templaza-elements'),
					'description'   => __('Select the predefined title text color.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'muted' => __('Muted', 'templaza-elements'),
						'emphasis' => __('Emphasis', 'templaza-elements'),
						'primary' => __('Primary', 'templaza-elements'),
						'secondary' => __('Secondary', 'templaza-elements'),
						'success' => __('Success', 'templaza-elements'),
						'warning' => __('Warning', 'templaza-elements'),
						'danger' => __('Danger', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'custom_title_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .tz-title' => 'color: {{VALUE}}',
					],
					'condition'     => array(
						'title_color'    => ''
					),
				),
				array(
					'id'            => 'title_text_transform',
					'type'          => Controls_Manager::SELECT,
					'label' => __('Transform', 'templaza-elements'),
					'description' => __('The following options will transform text into uppercased, capitalized or lowercased characters.', 'templaza-elements'),
					'options' => array(
						'' => __('Inherit', 'templaza-elements'),
						'uppercase' => __('Uppercase', 'templaza-elements'),
						'capitalize' => __('Capitalize', 'templaza-elements'),
						'lowercase' => __('Lowercase', 'templaza-elements'),
					),
					'default' => '',
				),

				//Content style
				array(
					'name'          => 'content_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Content Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .ui-content',
					'start_section' => 'content',
					'section_name'      => esc_html__('Content Settings', 'templaza-elements')
				),
				array(
					'id'    => 'content_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Select a predefined text style, including color, size and font-family.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'text-lead' => __('Lead', 'templaza-elements'),
						'text-meta' => __('Meta', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'id'            => 'content_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Custom Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .ui-content' => 'color: {{VALUE}}',
					],
				),
				array(
					'id'    => 'content_text_transform',
					'type' => Controls_Manager::SELECT,
					'label' => __('Transform', 'templaza-elements'),
					'description' => __('The following options will transform text into uppercased, capitalized or lowercased characters.', 'templaza-elements'),
					'options' => array(
						'' => __('Inherit', 'templaza-elements'),
						'uppercase' => __('Uppercase', 'templaza-elements'),
						'capitalize' => __('Capitalize', 'templaza-elements'),
						'lowercase' => __('Lowercase', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'content_dropcap',
					'label'         => esc_html__('Drop Cap', 'templaza-elements'),
					'description'   => __('Display the first letter of the paragraph as a large initial.', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
				),
				array(
					'id'    => 'content_column',
					'type' => Controls_Manager::SELECT,
					'label' => __('Columns', 'templaza-elements'),
					'description' => __('Set the number of text columns.', 'templaza-elements'),
					'options' => array(
						'' => __('None', 'templaza-elements'),
						'1-2' => __('Halves', 'templaza-elements'),
						'1-3' => __('Thirds', 'templaza-elements'),
						'1-4' => __('Quarters', 'templaza-elements'),
						'1-5' => __('Fifths', 'templaza-elements'),
						'1-6' => __('Sixths', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'content_column_divider',
					'label'         => esc_html__('Show dividers', 'templaza-elements'),
					'description'   => __('Show a divider between text columns.', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'condition' => array('content_column'    => ''),
				),
				array(
					'id'    => 'content_column_breakpoint',
					'type' => Controls_Manager::SELECT,
					'label' => __('Columns Breakpoint', 'templaza-elements'),
					'description' => __('Set the device width from which the text columns should apply', 'templaza-elements'),
					'options' => array(
						'' => __('Always', 'templaza-elements'),
						's' => __('Small (Phone Landscape)', 'templaza-elements'),
						'm' => __('Medium (Tablet Landscape)', 'templaza-elements'),
						'l' => __('Large (Desktop)', 'templaza-elements'),
						'xl' => __('X-Large (Large Screens)', 'templaza-elements'),
					),
					'default' => 'm',
					'conditions' => [
						'terms' => [
							['name' => 'content_column', 'operator' => '!==', 'value' => ''],
						],
					],
				),
				array(
					'id'    => 'content_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),

				// Image Settings
				array(
					'type'          => Controls_Manager::SELECT,
					'id'            => 'image_border',
					'label'         => esc_html__( 'Border', 'templaza-elements' ),
					'description'   => esc_html__( 'Select the image\'s border style.', 'templaza-elements' ),
					'options'       => array(
						'' => __('None', 'templaza-elements'),
						'uk-border-circle' => __('Circle', 'templaza-elements'),
						'uk-border-rounded' => __('Rounded', 'templaza-elements'),
						'uk-border-pill' => __('Pill', 'templaza-elements'),
					),
					'default'       => '',
					'start_section' => 'Image',
					'section_name'      => esc_html__('Image Settings', 'templaza-elements')
				),
				array(
					'id'    => 'positions',
					'type' => Controls_Manager::SELECT,
					'label' => __('Alignment', 'templaza-elements'),
					'description' => __('Align the image to the top, left, right or place it between the title and the content.', 'templaza-elements'),
					'options' => array(
						'top' => __('Top', 'templaza-elements'),
						'bottom' => __('Bottom', 'templaza-elements'),
						'left' => __('Left', 'templaza-elements'),
						'right' => __('Right', 'templaza-elements'),
					),
					'default' => 'top',
				),
				array(
					'id'    => 'grid_width',
					'type' => Controls_Manager::SELECT,
					'label' => __('Grid Width', 'templaza-elements'),
					'description' => __('Define the width of the navigation. Choose between percent and fixed widths or expand columns to the width of their content', 'templaza-elements'),
					'options' => array(
						'auto' => __('Auto', 'templaza-elements'),
						'4-5' => __('80%', 'templaza-elements'),
						'3-4' => __('75%', 'templaza-elements'),
						'2-3' => __('66%', 'templaza-elements'),
						'3-5' => __('60%', 'templaza-elements'),
						'1-2' => __('50%', 'templaza-elements'),
						'2-5' => __('40%', 'templaza-elements'),
						'1-3' => __('33%', 'templaza-elements'),
						'1-4' => __('25%', 'templaza-elements'),
						'1-5' => __('20%', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'2xlarge' => __('2X-Large', 'templaza-elements'),
					),
					'default' => '1-2',
					'conditions' => [
						'terms' => [
							[
								'name' => 'positions',
								'operator' => '!in',
								'value' => [
									'top',
									'bottom'
								]
							]
						],
					],
				),
				array(
					'id'=>'image_grid_column_gap',
					'type' => Controls_Manager::SELECT,
					'label' => __('Grid Column Gap', 'templaza-elements'),
					'description' => __('Set the size of the gap between the image and the content.', 'templaza-elements'),
					'options' => array(
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'collapse' => __('None', 'templaza-elements'),
					),
					'default' => '',
					'conditions' => [
						'terms' => [
							[
								'name' => 'positions',
								'operator' => '!in',
								'value' => [
									'top',
									'bottom'
								]
							]
						],
					],
				),
				array(
					'id'    => 'image_grid_row_gap',
					'type' => Controls_Manager::SELECT,
					'label' => __('Grid Row Gap', 'templaza-elements'),
					'description' => __('Set the size of the gap if the grid items stack.', 'templaza-elements'),
					'options' => array(
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'' => __('Default', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'collapse' => __('None', 'templaza-elements'),
					),
					'default' => '',
					'conditions' => [
						'terms' => [
							[
								'name' => 'positions',
								'operator' => '!in',
								'value' => [
									'top',
									'bottom'
								]
							]
						],
					],
				),
				array(
					'id'    => 'image_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
					'conditions' => [
						'terms' => [
							[
								'name' => 'positions',
								'operator' => '!in',
								'value' => [
									'top',
									'bottom'
								]
							]
						],
					],
				),
				array(
					'id'    => 'grid_breakpoint',
					'type' => Controls_Manager::SELECT,
					'label' => __('Grid Breakpoint', 'templaza-elements'),
					'description' => __('Set the breakpoint from which the navigation and content will stack.', 'templaza-elements'),
					'options' => array(
						's' => __('Small (Phone Landscape)', 'templaza-elements'),
						'm' => __('Medium (Tablet Landscape)', 'templaza-elements'),
						'l' => __('Large (Desktop)', 'templaza-elements'),
						'xl' => __('X-Large (Large Screens)', 'templaza-elements'),
					),
					'default' => 'm',
					'conditions' => [
						'terms' => [
							[
								'name' => 'positions',
								'operator' => '!in',
								'value' => [
									'top',
									'bottom'
								]
							]
						],
					],
				),
				array(
					'type'          => Controls_Manager::SWITCHER,
					'id'            => 'vertical_alignment',
					'label'         => esc_html__('Vertical Alignment', 'templaza-elements'),
					'description'   => __('Vertically center the navigation and content', 'templaza-elements'),
					'label_on'      => __( 'Yes', 'templaza-elements' ),
					'label_off'     => __( 'No', 'templaza-elements' ),
					'return_value'  => '1',
					'default'       => '0',
					'conditions' => [
						'terms' => [
							[
								'name' => 'positions',
								'operator' => '!in',
								'value' => [
									'top',
									'bottom'
								]
							]
						],
					],
				),

				//Button settings
				array(
					'id'    => 'all_button_title',
					'label' => __( 'Text', 'templaza-elements' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Read more' , 'templaza-elements' ),
					'label_block' => true,
					'start_section' => 'button',
					'section_name'      => esc_html__('Button Settings', 'templaza-elements')
				),
				array(
					'id'    => 'target',
					'type' => Controls_Manager::SELECT,
					'label' => __('Link New Tab', 'templaza-elements'),
					'options' => array(
						'' => __('Same Window', 'templaza-elements'),
						'_blank' => __('New Window', 'templaza-elements'),
					),
				),
				array(
					'id'    => 'button_style',
					'type' => Controls_Manager::SELECT,
					'label' => __('Style', 'templaza-elements'),
					'description' => __('Set the button style.', 'templaza-elements'),
					'options' => array(
						'' => __('Button Default', 'templaza-elements'),
						'primary' => __('Button Primary', 'templaza-elements'),
						'secondary' => __('Button Secondary', 'templaza-elements'),
						'danger' => __('Button Danger', 'templaza-elements'),
						'text' => __('Button Text', 'templaza-elements'),
						'link' => __('Link', 'templaza-elements'),
						'link-muted' => __('Link Muted', 'templaza-elements'),
						'link-text' => __('Link Text', 'templaza-elements'),
						'custom' => __('Custom', 'templaza-elements'),
					),
					'default' => '',
				),
				array(
					'name'          => 'button_font_family',
					'type'          => Group_Control_Typography::get_type(),
					'scheme'        => Typography::TYPOGRAPHY_1,
					'label'         => esc_html__('Button Font', 'templaza-elements'),
					'description'   => esc_html__('Select a font family, font size for the addon content.', 'templaza-elements'),
					'selector'      => '{{WRAPPER}} .uk-button',
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_background',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Background Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .uk-button' => 'background-color: {{VALUE}}',
					],
					'default' => '#1e87f0',
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Button Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .uk-button' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_background_hover',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Hover Background Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .uk-button:hover' => 'background-color: {{VALUE}}',
					],
					'default' => '#0f7ae5',
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'            => 'button_hover_color',
					'type'          =>  Controls_Manager::COLOR,
					'label'         => esc_html__('Hover Button Color', 'templaza-elements'),
					'selectors' => [
						'{{WRAPPER}} .uk-button:hover' => 'color: {{VALUE}}',
					],
					'condition' => array(
						'button_style'    => 'custom'
					),
				),
				array(
					'id'    => 'button_size',
					'type' => Controls_Manager::SELECT,
					'label' => __('Button Size', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'uk-button-small' => __('Small', 'templaza-elements'),
						'uk-button-large' => __('Large', 'templaza-elements'),
					),
				),
				array(
					'id'    => 'button_margin_top',
					'type' => Controls_Manager::SELECT,
					'label' => __('Margin Top', 'templaza-elements'),
					'description' => __('Set the top margin.', 'templaza-elements'),
					'options' => array(
						'' => __('Default', 'templaza-elements'),
						'small' => __('Small', 'templaza-elements'),
						'medium' => __('Medium', 'templaza-elements'),
						'large' => __('Large', 'templaza-elements'),
						'xlarge' => __('X-Large', 'templaza-elements'),
						'remove' => __('None', 'templaza-elements'),
					),
					'default' => '',
				),
			);
			return array_merge($options, $this->get_general_options());
		}

		public function get_template_name() {
			return 'base';
		}
	}
}