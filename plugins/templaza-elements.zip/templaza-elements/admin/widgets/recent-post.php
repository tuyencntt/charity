<?php
/*
 * Display posts
 * Widgets display posts by category
 */

class templaza_RecentPost extends WP_Widget{

    /* function construct*/
    function __construct() {
        parent::__construct(
            'tz_view_post',esc_html__('TZ: Recent Post', 'templaza-elements'),
            array('description' => esc_html__(' Display post by post type ', 'templaza-elements'))
        );
    }

    /* function widget */
    function  widget($args,$instance){
        extract($args);
        if( $instance['orderby'] != 'views'){
            $tzpostargs = array(
                'post_type'         => 'post',
                'posts_per_page'    => $instance['tzlmpost'],
                'ignore_sticky_posts' => 1,
                'orderby'           => $instance['orderby'],
                'post__not_in' => get_option( 'sticky_posts' )
            );
        }else{
            $tzpostargs = array(
                'post_type'         => 'post',
                'posts_per_page'    => $instance['tzlmpost'],
                'ignore_sticky_posts' => 1,
                'orderby'           => 'meta_value',
                'meta_key'    => 'post_views_count',
                'post__not_in' => get_option( 'sticky_posts' )
            );
        }
        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) )
            echo $args['before_title'] . $instance['title'] . $args['after_title'];
        ?>
            <div class="tz-recent-post">
                <?php
                $tz_query_post = new WP_Query($tzpostargs);
                if( $tz_query_post->have_posts() ):
                    while( $tz_query_post->have_posts() ): $tz_query_post->the_post();
                        ?>
                        <div class="tz-recent-item">
                            <?php
                            if ( has_post_thumbnail() ):
                                $tz_templaza_image_url = get_the_post_thumbnail_url(get_the_ID(),'large');
                            else:
                                $tz_templaza_image_url = get_template_directory_uri() . '/assets/images/recent.jpg';
                            endif;
                            ?>
                            <div class="recent_image" style="background-image: url(<?php echo esc_url($tz_templaza_image_url); ?>)">
                            </div>
                            <div class="tz-information">
                                <h4><a class="title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                <span class="tz-post-date"><i class="icon-calendar-full mr-2"></i><?php echo get_the_date(); ?></span>
                            </div>

                        </div>
                        <?php
                    endwhile; // end while(have_posts)
                    wp_reset_postdata();
                endif;  // end if(have_posts)
                ?>
            </div>
        <?php
        echo $args['after_widget'];
    }
    /* function form */
    function form($instance) {
        $instance = wp_parse_args( $instance, array(
            'title'             => 'Title',
            'tzlmpost'          =>  5,
            'orderby'           => 'date'
        ) );

        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
                <?php esc_html_e('Title','templaza-elements'); ?>
            </label>
            <br>
            <input type="text" name="<?php echo esc_attr($this->get_field_name('title')); ?>" id="<?php echo esc_attr($this->get_field_id('title')); ?>" class="widefat" value="<?php echo esc_html($instance['title']); ?>" >
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('tzlmpost')); ?>">
                <?php esc_html_e('Limit post','templaza-elements'); ?>
            </label>
            <input type="text" class="widefat"  id="<?php echo esc_attr($this->get_field_id('tzlmpost')); ?>" name="<?php echo esc_attr($this->get_field_name('tzlmpost')); ?>" value="<?php echo esc_html($instance['tzlmpost']); ?>" >
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('orderby')); ?>"><?php esc_html_e('Order By','templaza-elements'); ?></label>
            <select class="widefat" name="<?php echo $this->get_field_name( 'orderby' ); ?>" id="<?php echo $this->get_field_id( 'orderby' ); ?>" value="<?php echo $instance['orderby']; ?>">
                <option value="date" <?php if( $instance['orderby']=='date'){?>selected="selected"<?php } ?>><?php esc_html_e('Date','templaza-elements') ?></option>
                <option value="ID" <?php if( $instance['orderby']=='date'){?>selected="selected"<?php } ?>><?php esc_html_e('ID','templaza-elements') ?></option>
                <option value="none" <?php if( $instance['orderby']=='none'){?>selected="selected"<?php } ?>><?php esc_html_e('None','templaza-elements') ?></option>
                <option value="rand" <?php if( $instance['orderby']=='rand'){?>selected="selected"<?php } ?>><?php esc_html_e('Random','templaza-elements') ?></option>
                <option value="title" <?php if( $instance['orderby']=='title'){?>selected="selected"<?php } ?>><?php esc_html_e('Title','templaza-elements') ?></option>
                <option value="views" <?php if( $instance['orderby']=='views'){?>selected="selected"<?php } ?>><?php esc_html_e('Views','templaza-elements') ?></option>
            </select>
        </p>
        <?php
    }

    /* function update */
    function update($new_instance,$old_instance){
        $instance = $old_instance ;
        $instance['title']          =   $new_instance['title'];
        $instance['tzlmpost']       =   $new_instance['tzlmpost'];
//        $instance['post_type']       =   $new_instance['post_type'];
        $instance['orderby']       =   $new_instance['orderby'];
        return $instance;
    }
}

function templaza_register_widgets_recentpost() { register_widget( 'templaza_RecentPost' ); }
add_action( 'widgets_init', 'templaza_register_widgets_recentpost' );
?>